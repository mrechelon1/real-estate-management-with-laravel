<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
    });
    Route::get('/logout', function() {
     Session::forget('key');
      if(!Session::has('key'))
       {
          return Redirect('/');
       }
     });
    Route::get('/admin-amin', function () {
        return view('admin/index');
        });

        //Route::get('/user-admin', function () {
            //return view('user/index');
          //  });
Route::get('/user-admin','App\Http\Controllers\User_Controller@user_log');
Route::get('/user-review/{id}','App\Http\Controllers\User_Controller@user_reviews');
Route::get('/del-prop/{id}','App\Http\Controllers\User_Controller@del_prop');
Route::get('/del-review/{id}','App\Http\Controllers\User_Controller@del_review');
Route::get('/user_info','App\Http\Controllers\User_Controller@all_info');

Route::get('list-property', function () {
    return view('propupload');
});

Route::get('valued-property', function () {
    return view('allproperties');
});
Route::get('details', function () {
    return view('property_details');
});
Route::get('contact-us', function () {
    return view('contact');
});
Route::get('more-services', function () {
    return view('services');
});
Route::get('about-us', function () {
    return view('about');
});
Route::get('new-user', function () {
    return view('/user/signup');
});

Route::post('listprops','App\Http\Controllers\App_Controller@propsreg');
Route::get('/all_reviews','App\Http\Controllers\App_Controller@all_reviews');
Route::get('/all_info','App\Http\Controllers\App_Controller@all_info');
Route::get('/admin-portal','App\Http\Controllers\App_Controller@admin');
Route::get('/contact-info','App\Http\Controllers\App_Controller@all_contacts');
Route::get('/adverts','App\Http\Controllers\App_Controller@quotations');
Route::get('/new-compose','App\Http\Controllers\App_Controller@compose');
Route::get('/','App\Http\Controllers\App_Controller@view_properties');
Route::get('about-us','App\Http\Controllers\App_Controller@aboutus');
Route::get('valued-property','App\Http\Controllers\App_Controller@view_allproperties');
Route::get('search-props','App\Http\Controllers\App_Controller@propertysearch');
Route::post('send-message','App\Http\Controllers\App_Controller@send_email');
Route::post('submit-review','App\Http\Controllers\App_Controller@my_review');
Route::post('/send-info','App\Http\Controllers\App_Controller@send_info');
//Route::get('register', [RegisterController::class, 'register']);

Route::get('details/{id}/{email}','App\Http\Controllers\App_Controller@propdetails');
Route::get('/{type}','App\Http\Controllers\App_Controller@propcat');
Route::get('location/{locc}','App\Http\Controllers\App_Controller@propstate');
Route::get('/del-props/{id}','App\Http\Controllers\App_Controller@del_prop');
Route::get('/confirm-props/{id}','App\Http\Controllers\App_Controller@conf_prop');
Route::get('/delete-contacts/{id}','App\Http\Controllers\App_Controller@del_contact');
Route::get('/delete-review/{id}','App\Http\Controllers\App_Controller@del_review');
Route::get('/delete-info/{id}','App\Http\Controllers\App_Controller@del_mail');
Route::post('loginform','App\Http\Controllers\App_Controller@loginuser');
//Route::get('logout','App\Http\Controllers\App_Controller@logout');
Route::post('my_login','App\Http\Controllers\App_Controller@checklogin');
Route::get('del-record/{userid}','App\Http\Controllers\App_Controller@del_user');


// user routes


Route::get('/contact-user','App\Http\Controllers\User_Controller@all_contacts');

//register user
Route::post('reg-user','App\Http\Controllers\User_Controller@register_user');
