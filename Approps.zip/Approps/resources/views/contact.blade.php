<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps - Real Estate Management - Contact us</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
          @include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0" style="margin-top:-50px;">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
                <div class="col-md-6 p-5 mt-lg-5">
                    <h1 class="display-5 animated fadeIn mb-4">Contact Us</h1>
                        <nav aria-label="breadcrumb animated fadeIn">
                        <ol class="breadcrumb text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-body active" aria-current="page">Contact</li>
                        </ol>
                    </nav>
                </div>

            </div>
        </div>
        <!-- Header End -->


        <!-- Search Start -->
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 25px; margin-top:-30px;">
            <div class="container">
              <form action="search-props" method="get">
                  @csrf
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="text" required="required" name="kw" class="form-control border-0 py-3" placeholder="Search Keyword">
                            </div>
                            <div class="col-md-4">
                                <select name="type" class="form-select border-0 py-3">
                                    <option selected>Property Type</option>
                                    <option value="1">For Sale</option>
                                    <option value="2">For Rent</option>
                                    <option value="3">For Lease</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select name="location" class="form-select border-0 py-3">
                                    <option selected>Location</option>
                                    <OPTION value=Abia>Abia</OPTION>
                                    <OPTION value=Abuja>Abuja</OPTION>
                                    <OPTION value=Adamawa>Adamawa</OPTION>
                                    <OPTION value='Akwa Ibom'>Akwa Ibom</OPTION>
                                    <OPTION value=Anambra>Anambra</OPTION>
                                    <OPTION value=Bauchi>Bauchi</OPTION>
                                    <OPTION value=Bayelsa>Bayelsa</OPTION>
                                    <OPTION value=Benue>Benue</OPTION>
                                    <OPTION value='Cross River'>Cross River</OPTION>
                                    <OPTION value=Delta>Delta</OPTION>
                                    <OPTION value=Ebonyi>Ebonyi</OPTION>
                                    <OPTION value=Edo>Edo</OPTION>
                                    <OPTION value=Ekiti>Ekiti</OPTION>
                                    <OPTION value=Enugu>Enugu</OPTION>
                                    <OPTION value=Gombe>Gombe</OPTION>
                                    <OPTION value=Imo>Imo</OPTION>
                                    <OPTION value=Jigawa>Jigawa</OPTION>
                                    <OPTION value=Kaduna>Kaduna</OPTION>
                                    <OPTION value=Kano>Kano</OPTION>
                                    <OPTION value=Katsina>Katsina</OPTION>
                                    <OPTION value=Kebbi>Kebbi</OPTION>
                                    <OPTION value=Kogi>Kogi</OPTION>
                                    <OPTION value=Kwara>Kwara</OPTION>
                                    <OPTION value=Lagos>Lagos</OPTION>
                                    <OPTION value=Nassarawa>Nassarawa</OPTION>
                                    <OPTION value=Niger>Niger</OPTION>
                                    <OPTION value=Ogun>Ogun</OPTION>
                                    <OPTION value=Ondo>Ondo</OPTION>
                                    <OPTION value=Osun>Osun</OPTION>
                                    <OPTION value=Oyo>Oyo</OPTION>
                                    <OPTION value=Plateau>Plateau</OPTION>
                                    <OPTION value=Rivers>Rivers</OPTION>
                                    <OPTION value=Sokoto>Sokoto</OPTION>
                                    <OPTION value=Taraba>Taraba</OPTION>
                                    <OPTION value=Yobe>Yobe</OPTION>
                                    <OPTION value=Zamfara>Zamfara</OPTION>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-dark border-0 w-100 py-3" style="background-color:#3366FF;">Search</button>
                    </div>
                </div>
              </form>
            </div>
        </div>
        <!-- Search End -->


        <!-- Contact Start -->
        <div class="container-xxl py-5" style="margin-top:-40px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Contact Us</h1>
                    <p>Want to communicate with us? Fill the form below.</p>
                </div>
                <div class="row g-4">
                    <div class="col-12">
                        <div class="row gy-4">
                            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                                <div class="bg-light rounded p-3">
                                    <div class="d-flex align-items-center bg-white rounded p-3" style="border: 1px dashed rgba(0, 185, 142, .3)">
                                        <div class="icon me-3" style="width: 45px; height: 45px;">
                                            <i class="fa fa-map-marker-alt text-primary"></i>
                                        </div>
                                        <span>Alausa, Ikeja, Lagos, Nigeria</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                                <div class="bg-light rounded p-3">
                                    <div class="d-flex align-items-center bg-white rounded p-3" style="border: 1px dashed rgba(0, 185, 142, .3)">
                                        <div class="icon me-3" style="width: 45px; height: 45px;">
                                            <i class="fa fa-envelope-open text-primary"></i>
                                        </div>
                                        <span>contact@approps.ng</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                                <div class="bg-light rounded p-3">
                                    <div class="d-flex align-items-center bg-white rounded p-3" style="border: 1px dashed rgba(0, 185, 142, .3)">
                                        <div class="icon me-3" style="width: 45px; height: 45px;">
                                            <i class="fa fa-phone-alt text-primary"></i>
                                        </div>
                                        <span>+2348055037772</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <iframe class="position-relative rounded w-100 h-100"
                            src="https://www.google.com/maps/embed?pb=Alausa%%Ikeja%%Lagos%%Nigeria"
                            frameborder="0" style="min-height: 400px; border:0;" allowfullscreen="" aria-hidden="false"
                            tabindex="0"></iframe>
                    </div>
                    <div class="col-md-6">
                        <div class="wow fadeInUp" data-wow-delay="0.5s">
                            <h4 class="mb-4">Contact us</a>.</h4>
                            @if($message = Session:: get('insert_success'))
                            <table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="center" style=" font:white;">	{{$message}}</td>
                              </tr>
                            </table>
                          {{  Session::forget('insert_success'); }}
                            @endif
                            <br>
                            <form action="send-message" method="post">
                                @csrf
                                <div class="row g-3">

                                  <div class="col-12">
                                      <div class="form-floating">
                                        <select name="type" class="form-select border-1 py-3">
                                            <option selected>Contact Type</option>
                                            <option value="Information">Information</option>
                                            <option value="Enquiry">Enquiry</option>
                                            <option value="Advertizement">Advertizement</option>
                                            <option value="Premium Listing">Premium Listing</option>
                                            <option value="Report an agent">Report an agent</option>
                                        </select>
                                      </div>
                                  </div>

                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="text" name="gname" max="250" required="required" class="form-control" id="name" placeholder="Your Name">
                                            <label for="name">Your Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="email" class="form-control" required="required" id="email" name="gemail" placeholder="Your Email">
                                            <label for="email">Your Email</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" max="250" required="required" name="title" id="subject" placeholder="Subject">
                                            <label for="subject">Subject</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <textarea class="form-control" maxlength="500" minlength="250" name="me" placeholder="Leave a message here" id="message" style="height: 150px" required="required"></textarea>
                                            <label for="message">Message</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button class="btn btn-primary w-100 py-3" type="submit">Send Message</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->


        <!-- Footer Start -->
          @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
