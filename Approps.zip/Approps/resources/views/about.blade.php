<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps - Real Estate Management - About us</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0" >
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
              <div class="col-md-6 p-5 mt-lg-5">
                <br><br><br>
                  <h1 class="display-5 animated fadeIn mb-4"><span class="text-primary">About</span> Us</h1>

                  <nav aria-label="breadcrumb animated fadeIn">
                  <ol class="breadcrumb text-uppercase">
                      <li class="breadcrumb-item"><a href="/">Home</a></li>

                      <li class="breadcrumb-item text-body active" aria-current="page">About us</li>
                  </ol>
              </nav>
                    <a href="list-property" class="btn btn-primary py-3 px-5 me-3 animated fadeIn">Get Started</a>
              </div>
                <div class="col-md-6 animated fadeIn">
                    <img class="img-fluid" src="img/header2.jpg" alt="" >
                </div>
            </div>
        </div>

        <!-- Header End -->


        <!-- Search Start -->
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 25px;">
            <div class="container">
              <form action="search-props" method="get">
                  @csrf
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="text" name="kw" class="form-control border-0 py-3" placeholder="Search Keyword">
                            </div>
                            <div class="col-md-4">
                                <select name="type" class="form-select border-0 py-3">
                                    <option selected>Property Type</option>
                                    <option value="1">For Sale</option>
                                    <option value="2">For Rent</option>
                                    <option value="3">For Lease</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select name="location" class="form-select border-0 py-3">
                                    <option selected>Location</option>
                                    <OPTION value=Abia>Abia</OPTION>
                                    <OPTION value=Abuja>Abuja</OPTION>
                                    <OPTION value=Adamawa>Adamawa</OPTION>
                                    <OPTION value='Akwa Ibom'>Akwa Ibom</OPTION>
                                    <OPTION value=Anambra>Anambra</OPTION>
                                    <OPTION value=Bauchi>Bauchi</OPTION>
                                    <OPTION value=Bayelsa>Bayelsa</OPTION>
                                    <OPTION value=Benue>Benue</OPTION>
                                    <OPTION value='Cross River'>Cross River</OPTION>
                                    <OPTION value=Delta>Delta</OPTION>
                                    <OPTION value=Ebonyi>Ebonyi</OPTION>
                                    <OPTION value=Edo>Edo</OPTION>
                                    <OPTION value=Ekiti>Ekiti</OPTION>
                                    <OPTION value=Enugu>Enugu</OPTION>
                                    <OPTION value=Gombe>Gombe</OPTION>
                                    <OPTION value=Imo>Imo</OPTION>
                                    <OPTION value=Jigawa>Jigawa</OPTION>
                                    <OPTION value=Kaduna>Kaduna</OPTION>
                                    <OPTION value=Kano>Kano</OPTION>
                                    <OPTION value=Katsina>Katsina</OPTION>
                                    <OPTION value=Kebbi>Kebbi</OPTION>
                                    <OPTION value=Kogi>Kogi</OPTION>
                                    <OPTION value=Kwara>Kwara</OPTION>
                                    <OPTION value=Lagos>Lagos</OPTION>
                                    <OPTION value=Nassarawa>Nassarawa</OPTION>
                                    <OPTION value=Niger>Niger</OPTION>
                                    <OPTION value=Ogun>Ogun</OPTION>
                                    <OPTION value=Ondo>Ondo</OPTION>
                                    <OPTION value=Osun>Osun</OPTION>
                                    <OPTION value=Oyo>Oyo</OPTION>
                                    <OPTION value=Plateau>Plateau</OPTION>
                                    <OPTION value=Rivers>Rivers</OPTION>
                                    <OPTION value=Sokoto>Sokoto</OPTION>
                                    <OPTION value=Taraba>Taraba</OPTION>
                                    <OPTION value=Yobe>Yobe</OPTION>
                                    <OPTION value=Zamfara>Zamfara</OPTION>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-dark border-0 w-100 py-3" style="background-color:#3366FF;">Search</button>
                    </div>
                </div>
              </form>
            </div>
        </div>
        <!-- Search End -->


        <!-- Category Start -->

        <!-- Category End -->
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <h1 class="mb-3">Most Searched Locations</h1>
            <p>People seems to get properties more in the locations below: A trial may convince you with immediate profit.</p>
        </div>
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 25px; margin-top:-20px;">
            <div class="container">
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4" style="width:20%">
                                @foreach($lagos as $lag)
                            <a href="/location/{{$lag->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;">Lagos ({{$lag->count}}) <br>Properties</button></a>
                                  @endforeach
                          </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($abuja as $abu)
                            <a href="/location/{{$abu->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;">Abuja ({{$abu->count}}) <br>Properties</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($ogun as $ogu)
                            <a href="/location/{{$ogu->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;">Ogun ({{$ogu->count}}) <br>Properties</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%; height:50%;">
                                @foreach($ph as $p)
                            <a href="/location/{{$p->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;" >P/H ({{$p->count}}) <br>Properties</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($oyo as $oy)
                              <a href="/location/{{$oy->p_state}}"> <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;" >Ibadan ({{$oy->count}}) <br>Properties</button></a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2" >
                        @foreach($others as $othe)
                          <a href="/location/{{$othe->p_state}}"><button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;">Others ({{$othe->count}}) <br>Properties</button></a>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="about-img position-relative overflow-hidden p-5 pe-0">
                            <img class="img-fluid w-100" src="img/about.jpg">
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">#1 Place To Find The Perfect Property</h1>
                        <p class="mb-4">Looking for where to invest your money safely and profitably? Real estate investment has got you answered. A significant percentage increament on annual basis for your investment.</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Property for Rent</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Property for Sale</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Search for different categories</p>
                        <a class="btn btn-primary py-3 px-5 mt-3" href="">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Property List Start -->

        <!-- Property List End -->


        <!-- Call to Action Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="img/header.jpg" alt="">
                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                  <h1 class="mb-3">Want to sell your property quickly?</h1>
                                  <p>Advertise with us. Placing an advert on Approps.ng can give you a fast access from users. You can also subscribe to a premium listing and promote your property listing</p>
                            </div>
                                <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Get a quote</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->


        <!-- Team Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Property Agents</h1>
                    <p>Conatct our certified agents. You will never regret doing business with them</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Hargitee Properties</h5>
                                <small>Address:</small>
                                  <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Approps Property Limited</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Essential Property</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Affordable Properties</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->


        <!-- Testimonial Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Our Clients Say!</h1>
                    <p>Our clients are the reasons we are being in business. Checkout some of their testimonial.</p>
                </div>
                <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>We have been dealing with approps for years and their services are reliable</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Mr James Jude</h6>
                                    <small>Real Estate Consultant</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>To get your dreamt property, use approps, very reliable with affordable properties.</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Dr Ayomide Adebayo</h6>
                                    <small>Agent</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>Approps is reliable. We have acquired lots of properties on approps.ng</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Engr Bishop Enenche</h6>
                                    <small>Real Estate Developer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial End -->


        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
