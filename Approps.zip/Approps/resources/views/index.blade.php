<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
  <title>Approps - Real Estate Management, Property listing, properties in Nigeria</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="keywords" content="Properties in Nigeria, Properties in Lagos State, Ibadan, Properties in Ogun State, Property Valuation, List your properties, Property listing site, Find property in Nigeria" />
   <meta content="" name="description" content="Approps.ng is the Nigeria number one property listing site with elegant and affordable properties of various types and location such as Lagos, Abuja, Ogun state and many more" >

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
              <div class="col-md-6 p-5 mt-lg-5">
                <br>
                  <h1 class="display-5 animated fadeIn mb-4">Find A <span class="text-primary">Perfect Home</span> To Live With Your Family</h1>
                  <p class="animated fadeIn mb-4 pb-2">Approps apartment offer you the link between the seller and the buyer within your appropriated budget. Get a property of your dream with no stress.</p>
                  <a href="list-property" class="btn btn-primary py-3 px-5 me-3 animated fadeIn">Get Started</a>
              </div>
                <div class="col-md-6 animated fadeIn">
                    <img class="img-fluid" src="img/header2.jpg" alt="" >
                </div>
            </div>
        </div>

        <!-- Header End -->


        <!-- Search Start -->
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 15px; ">
            <div class="container">
              <form action="search-props" method="get">
                  @csrf
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="text" name="kw" class="form-control border-0 py-3" placeholder="Search Keyword">
                            </div>
                            <div class="col-md-4">
                                <select name="type" class="form-select border-0 py-3">
                                    <option selected>Property Type</option>
                                    <option value="1">For Sale</option>
                                    <option value="2">For Rent</option>
                                    <option value="3">For Lease</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select name="location" class="form-select border-0 py-3">
                                    <option selected>Location</option>
                                    <OPTION value=Abia>Abia</OPTION>
                                    <OPTION value=Abuja>Abuja</OPTION>
                                    <OPTION value=Adamawa>Adamawa</OPTION>
                                    <OPTION value='Akwa Ibom'>Akwa Ibom</OPTION>
                                    <OPTION value=Anambra>Anambra</OPTION>
                                    <OPTION value=Bauchi>Bauchi</OPTION>
                                    <OPTION value=Bayelsa>Bayelsa</OPTION>
                                    <OPTION value=Benue>Benue</OPTION>
                                    <OPTION value='Cross River'>Cross River</OPTION>
                                    <OPTION value=Delta>Delta</OPTION>
                                    <OPTION value=Ebonyi>Ebonyi</OPTION>
                                    <OPTION value=Edo>Edo</OPTION>
                                    <OPTION value=Ekiti>Ekiti</OPTION>
                                    <OPTION value=Enugu>Enugu</OPTION>
                                    <OPTION value=Gombe>Gombe</OPTION>
                                    <OPTION value=Imo>Imo</OPTION>
                                    <OPTION value=Jigawa>Jigawa</OPTION>
                                    <OPTION value=Kaduna>Kaduna</OPTION>
                                    <OPTION value=Kano>Kano</OPTION>
                                    <OPTION value=Katsina>Katsina</OPTION>
                                    <OPTION value=Kebbi>Kebbi</OPTION>
                                    <OPTION value=Kogi>Kogi</OPTION>
                                    <OPTION value=Kwara>Kwara</OPTION>
                                    <OPTION value=Lagos>Lagos</OPTION>
                                    <OPTION value=Nassarawa>Nassarawa</OPTION>
                                    <OPTION value=Niger>Niger</OPTION>
                                    <OPTION value=Ogun>Ogun</OPTION>
                                    <OPTION value=Ondo>Ondo</OPTION>
                                    <OPTION value=Osun>Osun</OPTION>
                                    <OPTION value=Oyo>Oyo</OPTION>
                                    <OPTION value=Plateau>Plateau</OPTION>
                                    <OPTION value=Rivers>Rivers</OPTION>
                                    <OPTION value=Sokoto>Sokoto</OPTION>
                                    <OPTION value=Taraba>Taraba</OPTION>
                                    <OPTION value=Yobe>Yobe</OPTION>
                                    <OPTION value=Zamfara>Zamfara</OPTION>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-dark border-0 w-100 py-3" style="background-color:#3366FF;">Search</button>
                    </div>
                </div>
              </form>
            </div>
        </div>
        <!-- Search End -->


        <!-- Category Start -->
        <div class="container-xxl py-5" style="margin-top:-70px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Property Types</h1>
                    <p>Choice of property is crucial to us. There are variety of properties to choose from. Get an apartment of your choice without further delay.</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                      @foreach($apart as $user)

                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-apartment.png" alt="Icon">
                                </div>
                                <h6>Apartment</h6>
                                <span>

                                  {{$user->count}}

                                  Properties</span>
                            </div>
                        </a>
                          @endforeach

                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                       @foreach($villa as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-villa.png" alt="Icon">
                                </div>
                                <h6>Villa</h6>
                                <span>
                                {{$user->count}}
                                 Properties</span>
                            </div>
                        </a>
                          @endforeach
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                        @foreach($home as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-house.png" alt="Icon">
                                </div>
                                <h6>Home</h6>
                                <span>
                                {{$user->count}}
                                   Properties</span>
                            </div>
                        </a>
                        @endforeach
                    </div>

                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                      @foreach($build as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-building.png" alt="Icon">
                                </div>
                                <h6>Building</h6>
                                <span>
                                {{$user->count}}
                                   Properties</span>
                            </div>
                        </a>
                        @endforeach
                    </div>

                </div>
            </div>
        </div>
        <!-- Category End -->
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <h1 class="mb-3">Most Searched Locations</h1>
            <p>People seems to get properties more in the locations below: A trial may convince you with immediate profit.</p>
        </div>
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 25px; margin-top:-20px;">
            <div class="container">
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4" style="width:20%">
                                @foreach($lagos as $lag)
                            <a href="/location/{{$lag->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px; font-size:small;">Lagos ({{$lag->count}})</button></a>
                                  @endforeach
                          </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($abuja as $abu)
                            <a href="/location/{{$abu->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;font-size:small;">Abuja ({{$abu->count}})</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($ogun as $ogu)
                            <a href="/location/{{$ogu->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;font-size:small;">Ogun ({{$ogu->count}})</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%; height:50%;">
                                @foreach($ph as $p)
                            <a href="/location/{{$p->p_state}}">  <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;font-size:small;" >P/H ({{$p->count}})</button></a>
                                  @endforeach
                            </div>
                            <div class="col-md-4" style="width:20%">
                                @foreach($oyo as $oy)
                              <a href="/location/{{$oy->p_state}}"> <button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;font-size:small;" >Ibadan ({{$oy->count}})</button></a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2" >
                        @foreach($others as $othe)
                          <a href="/location/{{$othe->p_state}}"><button class="btn btn-dark border-0 w-100 py-3" style="width:20%; height:80px;font-size:small;">Others ({{$othe->count}})</button></a>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <!-- About Start -->
        <div class="container-xxl py-5" style="margin-top:-70px;">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="about-img position-relative overflow-hidden p-5 pe-0">
                            <img class="img-fluid w-100" src="img/about.jpg">
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">#1 Place To Find The Perfect Property</h1>
                        <p class="mb-4">Looking for where to invest your money safely and profitably? Real estate investment has got you answered. A significant percentage increament on annual basis for your investment.</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Property for Rent</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Property for Sale</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Search for different categories</p>
                        <a class="btn btn-primary py-3 px-5 mt-3" href="">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Property List Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Property Listing</h1>
                            <p>Looking for a property of your dreams, Approps.ng has numerous list of properties that you can check from</p>
                        </div>
                    </div>
                    <div class="col-lg-6 text-start text-lg-end wow slideInRight" data-wow-delay="0.1s">
                        <ul class="nav nav-pills d-inline-flex justify-content-end mb-5">
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-primary active" data-bs-toggle="pill" href="#tab-1">Featured</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-primary" data-bs-toggle="pill" href="#tab-2">For Sell</a>
                            </li>
                            <li class="nav-item me-0">
                                <a class="btn btn-outline-primary" data-bs-toggle="pill" href="#tab-3">For Rent</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <div class="row g-4">

                                  @foreach($users as $user)
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href="/details/{{$user->id}}/{{$user->email}}"><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                        <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                        <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                        <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                        <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                        <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                    </div>
                                </div>
                            </div>
                                    @endforeach

                            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
                                <a class="btn btn-primary py-3 px-5" href="{{url('valued-property')}}">Browse More Property</a>
                            </div>
                        </div>
                    </div>

                    <div id="tab-2" class="tab-pane fade show p-0">
                        <div class="row g-4">

                            @foreach($users2 as $user)
                            <div class="col-lg-4 col-md-6">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href="/details/{{$user->id}}/{{$user->email}}"><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                        <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                        <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                        <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                        <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                        <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                    </div>
                                </div>
                            </div>
                              @endforeach

                            <div class="col-12 text-center">

                                <a class="btn btn-primary py-3 px-5" href="{{url('valued-property')}}">Browse More Property</a>
                            </div>
                        </div>
                    </div>

                    <div id="tab-3" class="tab-pane fade show p-0">
                        <div class="row g-4">
                          @foreach($user3 as $user)
                          <div class="col-lg-4 col-md-6">
                              <div class="property-item rounded overflow-hidden">
                                  <div class="position-relative overflow-hidden">
                                    <a href="/details/{{$user->id}}/{{$user->email}}"><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                      <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                      <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                  </div>
                                  <div class="p-4 pb-0">
                                      <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                      <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                      <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                  </div>
                                  <div class="d-flex border-top">
                                      <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                      <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                      <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                  </div>
                              </div>
                          </div>
                            @endforeach
                            <div class="col-12 text-center">
                                <a class="btn btn-primary py-3 px-5" href="{{url('valued-property')}}">Browse More Property</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Property List End -->

        <div class="container-xxl py-5" style="margin-top:-50px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Other Categories</h1>
                    <p>Choice of property is crucial to us. There are variety of properties to choose from. Get an apartment of your choice without further delay.</p>
                </div>
                <div class="row g-4">

                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                       @foreach($office as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-housing.png" alt="Icon">
                                </div>
                                <h6>Office</h6>
                                <span>
                                {{$user->count}}
                                   Properties</span>
                            </div>
                        </a>
                        @endforeach
                    </div>

                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                      @foreach($town as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-neighborhood.png" alt="Icon">
                                </div>
                                <h6>WareHouse</h6>
                                <span>
                                {{$user->count}}
                                   Properties</span>
                            </div>
                        </a>
                        @endforeach
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                      @foreach($shop as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-condominium.png" alt="Icon">
                                </div>
                                <h6>Shop</h6>
                                <span>
                                {{$user->count}}
                                 Properties</span>
                            </div>
                        </a>
                          @endforeach
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                      @foreach($garage as $user)
                        <a class="cat-item d-block bg-light text-center rounded p-3" href="/{{$user->p_type}}">
                            <div class="rounded p-4">
                                <div class="icon mb-3">
                                    <img class="img-fluid" src="img/icon-luxury.png" alt="Icon">
                                </div>
                                <h6>Garage</h6>
                                <span>
                                {{$user->count}}
                                 Properties</span>
                            </div>
                        </a>
                          @endforeach
                    </div>
                </div>
            </div>
        </div>


        <!-- Call to Action Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="img/header.jpg" alt="">
                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                  <h1 class="mb-3">Want to sell your property quickly?</h1>
                                  <p>Advertise with us. Placing an advert on Approps.ng can give you a fast access from users. You can also subscribe to a premium listing and promote your properties.</p>
                            </div>
                                <a href="/contact-us" class="btn btn-primary py-3 px-4 me-2" style="margin-bottom:5px;"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="https://wa.me/2348055037772" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Get a quote</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->


        <!-- Team Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Property Agents</h1>
                    <p>Contact our certified agents. You will not regret doing business with them.</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Hargitee Properties</h5>
                                <small>Address:</small>
                                  <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Echelon Properties Limited</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Essential Property</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Affordable Properties</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->


        <!-- Testimonial Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">What Our Clients Say!</h1>
                    <p>Our clients are the reasons we are being in business. Checkout some of their testimonial.</p>
                </div>
                <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>We have been dealing with approps for years and their services are reliable</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Mr James Jude</h6>
                                    <small>Real Estate Consultant</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>To get your dreamt property, use approps, very reliable with affordable properties.</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Dr Ayomide Adebayo</h6>
                                    <small>Agent</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item bg-light rounded p-3">
                        <div class="bg-white border rounded p-4">
                            <p>Approps is reliable. We have acquired lots of properties on approps.ng</p>
                            <div class="d-flex align-items-center">
                                <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial.jpg" style="width: 45px; height: 45px;">
                                <div class="ps-3">
                                    <h6 class="fw-bold mb-1">Engr Bishop Enenche</h6>
                                    <small>Real Estate Developer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial End -->


        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
      <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

          </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>


</body>

</html>
