<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Review & Rating System in PHP & Mysql using Ajax</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
      <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="container">

    	<div class="card">
    		<div class="card-header">Property Review</div>
    		<div class="card-body">
    			<div class="row">
    				<div class="col-sm-4 text-center">
              @foreach($review as $user)
              <?php $r= $user->count; ?>
    					<h1 class="text-warning mt-4 mb-4">
    						<b><span id="average_rating">  {{($r/100)*5 }}</span> / 5</b>
    					</h1>
    					<div class="mb-3">
    						<i class="fas fa-star star-light mr-1 main_star"></i>
                            <i class="fas fa-star star-light mr-1 main_star"></i>
                            <i class="fas fa-star star-light mr-1 main_star"></i>
                            <i class="fas fa-star star-light mr-1 main_star"></i>
                            <i class="fas fa-star star-light mr-1 main_star"></i>
	    				</div>
    					<h3><span id="total_review">

                {{$user->count }}

              </span> Review</h3>
                @endforeach
    				</div>
    				<div class="col-sm-4">
    					         <p>
                            <div class="progress-label-left">(<span id="total_five_star_review">
                                @foreach($fivestar as $user)
                                {{$user->count }}


                            </span>)<b> 5 </b> <i class="fas fa-star text-warning"></i></div>

                            <div class="w3-light-grey">
    <div class="w3-green" style="height:20px;width:{{$user->count }}%"></div>
      @endforeach
  </div>
                        </p>
    					         <p>
                            <div class="progress-label-left">(<span id="total_five_star_review">

                              @foreach($fourstar as $user)
                              {{$user->count }}



                            </span>)<b> 4 </b> <i class="fas fa-star text-warning"></i></div>

                            <div class="w3-light-grey">
    <div class="w3-green" style="height:20px;width:{{$user->count }}%"></div>
      @endforeach
  </div>
                        </p>
                        <p>
                                      <div class="progress-label-left">(<span id="total_five_star_review">
                                        @foreach($threestar as $user)
                                        {{$user->count }}


                                      </span>)<b> 3 </b> <i class="fas fa-star text-warning"></i></div>


                                      <div class="w3-light-grey">
              <div class="w3-green" style="height:20px;width:{{$user->count }}%"></div>
              @endforeach

            </div>
                                  </p>

    				</div>
    				<div class="col-sm-4 text-center">
    					<h3 class="mt-4 mb-3">Write Review Here</h3>
    					<button type="button" name="add_review" id="add_review" onclick="openForm()" class="btn btn-primary">Review</button>
    				</div>



    			</div>
    		</div>
    	</div>
    	<div class="mt-5" id="review_content"></div>
    </div>


</body>
</html>
