

<aside class="sidebar-left">
  <nav class="navbar navbar-inverse">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <h1><a class="navbar-brand" href="/user-admin"><span><img src="/asset/images/approps.png" width="30"></span> APPROPS<span class="dashboard_text">Property Management</span></a></h1>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="sidebar-menu">
          <li class="header">USER PORTAL</li>
          <br>
            <i class="fa fa-dashboard"></i> <span><a href="/user-admin">Dashboard</a></span>

    <li class="treeview">
            <a href="#">
            <i class="fa fa-laptop"></i>
            <span>Properties</span>
            <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><a href="/user-admin"><i class="fa fa-angle-right"></i> Edit</a></li>
              <li><a href="/user-admin"><i class="fa fa-angle-right"></i>Delete</a></li>
            </ul>
          </li>
          <li class="treeview">
            <a href="user-admin">
            <i class="fa fa-pie-chart"></i>
            <span>Profile</span>
            <span class="label label-primary pull-right">Profile</span>
            </a>
          </li>
          <li class="treeview">
          <li class="treeview">
            <a href="#">
            <i class="fa fa-laptop"></i>
            <span>Contacts</span>
            <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><a href="#"><i class="fa fa-angle-right"></i> All Contacts</a></li>
              <li><a href="#"><i class="fa fa-angle-right"></i> New Contacts</a></li>
              <li><a href="#"><i class="fa fa-angle-right"></i> Information</a></li>

            </ul>
          </li>

          <li class="treeview">
            <a href="#">
            <i class="fa fa-edit"></i> <span>Reviews</span>
            <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><a href="/user-admin"><i class="fa fa-angle-right"></i> All Reviews</a></li>
              <li><a href="/user-admin"><i class="fa fa-angle-right"></i> New Reviews</a></li>
            </ul>
          </li>



          <li class="header">INFO.</li>
          <li><a href="/user_info"><i class="fa fa-angle-right text-red"></i> <span>Important</span></a></li>
          <li><a href="/user_info"><i class="fa fa-angle-right text-yellow"></i> <span>Warning</span></a></li>
          <li><a href="/user_info"><i class="fa fa-angle-right text-aqua"></i> <span>Information</span></a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
  </nav>
</aside>
</div>
<!--left-fixed -navigation-->

<!-- header-starts -->
<div class="sticky-header header-section ">
  <div class="header-left">
    <!--toggle button start-->
    <button id="showLeftPush"><i class="fa fa-bars"></i></button>
    <!--toggle button end-->
    <div class="profile_details_left"><!--notifications of menu start -->
      <ul class="nofitications-dropdown">
        <li class="dropdown head-dpdn">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-envelope"></i><span class="badge">  @foreach($countcontact as $user)
              {{$user->count}}
                @endforeach</span></a>
          <ul class="dropdown-menu">
            <li>
              <div class="notification_header">
                <h3><a href="#">You have
                  @foreach($countcontact as $user)
                    {{$user->count}}
                      @endforeach

                   new messages</a></h3>
              </div>
            </li>

          </ul>
        </li>
        <li class="dropdown head-dpdn">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">  @foreach($today as $user)
              {{$user->count}}
                @endforeach</span></a>
          <ul class="dropdown-menu">
            <li>
              <div class="notification_header">
                <h3><a href="user-admin">Today Listing #
                  @foreach($today as $user)
                    {{$user->count}}
                      @endforeach
                    </a>
                </h3>
              </div>
            </li>

          </ul>
        </li>

      </ul>
      <div class="clearfix"> </div>
    </div>
    <!--notification menu end -->
    <div class="clearfix"> </div>
  </div>
  <div class="header-right">


    <!--search-box-->
    <div class="search-box" style="margin-left:-5px;">
      <form class="input">
        <input class="sb-search-input input__field--madoka" placeholder="Search..." type="search" id="input-31" />
        <label class="input__label" for="input-31">
          <svg class="graphic" width="100%" height="100%" viewBox="0 0 404 77" preserveAspectRatio="none">
            <path d="m0,0l404,0l0,77l-404,0l0,-77z"/>
          </svg>
        </label>
      </form>
    </div><!--//end-search-box-->

    <div class="profile_details" >
      <ul>
        <li class="dropdown profile_details_drop">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <div class="profile_img">
              <span class="prfil-img"><img src="/asset/images/2.jpg" width="50" alt=""> </span>
              <div class="user-name" >


                <p>
                  @if($message = Session:: get('key'))
                {{substr($message, 0,8)}}..

                  @endif
                </p>

                <span>User</span>
              </div>
              <i class="fa fa-angle-down lnr"></i>
              <i class="fa fa-angle-up lnr"></i>
              <div class="clearfix"></div>
            </div>
          </a>
          <ul class="dropdown-menu drp-mnu">
            <li> <a href="#"><i ></i>  @if($message = Session:: get('key'))
            {{$message}}

              @endif</a> </li>
            <li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li>
            <li> <a href="#"><i class="fa fa-user"></i> My Account</a> </li>
            <li> <a href="#"><i class="fa fa-suitcase"></i> Profile</a> </li>
            <li> <a href="/logout"><i class="fa fa-sign-out"></i> Logout</a> </li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="clearfix"> </div>
  </div>
  <div class="clearfix"> </div>
</div>
