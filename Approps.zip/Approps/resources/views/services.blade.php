<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps - Real Estate Management- More services</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
              <div class="col-md-6 p-5 mt-lg-5">
                <br><br><br>
                  <h1 class="display-5 animated fadeIn mb-4">Approps.ng offers range of <span class="text-primary">services</span> which include:</h1>
                  <p class="animated fadeIn mb-4 pb-2"><b>Investment, Appropriation, Budgeting, Valuation and Consultancy.</b></p>
                  <a href="#" class="btn btn-primary py-3 px-5 me-3 animated fadeIn" style="background-color:#3366FF;">Read More</a>
              </div>
                <div class="col-md-6 animated fadeIn">
                    <img class="img-fluid" src="/img/services.png" alt="Approps Services Limited" style="margin-top:-60px;">
                </div>
            </div>
        </div>

        <!-- Header End -->


        <!-- Search Start -->

        <!-- Search End -->


        <!-- Category Start -->

        <!-- Category End -->


        <!-- About Start -->

        <!-- About End -->
<hr>

        <!-- Property List Start -->


            <div class="container-xxl py-5" style="margin-top:-40px;">
                <div class="container">
                    <h1 class="mb-3">Investment</h1>
                    <div class="bg-light rounded p-3">
                        <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                            <div class="row g-5 align-items-center">
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                    <img class="img-fluid rounded w-100" src="/img/invest.png" alt="">
                                </div>
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="mb-4">
                                      <h5 class="mb-3">Find How to Invest your Money</h5>
                                      <p>
                                        Search For How I Can Invest Money at Approps Investment Services. Get Attractive and Relevant Results. Fast Response. An investment is an asset or item acquired with the goal of generating income or appreciation. Appreciation refers to an increase in the value of an asset over time. Investing is an effective way to put your money to work and potentially build wealth. Smart investing may allow your money to outpace inflation and increase in value. The greater growth potential of investing is primarily due to the power of compounding and the risk-return tradeoff. Get Latest Info.
                                      </p>
                                </div>
                                    <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                    <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Visit Website</a>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- Property List End -->

            <div class="container-xxl py-5">
                <div class="container">
                    <h1 class="mb-3">Appropriation</h1>
                    <div class="bg-light rounded p-3">
                        <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                            <div class="row g-5 align-items-center">
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                    <img class="img-fluid rounded w-100" src="/img/appro.png"  alt="">
                                </div>
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="mb-4">
                                      <h5 class="mb-3">Appropriate Your Expenditures With us</h5>
                                      <p>
                                        Appropriation is the act of setting aside money for a specific purpose. There are two type of existing appropriations :1) continuing and 2) automatic. Continuing appropriations refer to appropriations available to support obligations for a specified purpose or project, such as multi-year construction projects which require the incurrence of obligations even beyond the budget year.
                                      </p>
                                </div>
                                    <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                    <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Visit Website</a>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- Call to Action Start -->

        <!-- Call to Action End -->
        <div class="container-xxl py-5">
            <div class="container">
                <h1 class="mb-3">Budgeting</h1>
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="/img/budget.png" alt="">
                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                  <h5 class="mb-3">Approps Budgeting Services.</h5>
                                  <p>
                                  Budgeting is the process of creating a plan to spend your money.  This spending plan is called a budget. Creating this spending plan allows you to determine in advance whether you will have enough money to do the things you need to do or would like to do. Budgeting is simply balancing your expenses with your income. A budget helps create financial stability. By tracking expenses and following a plan, a budget makes it easier to pay bills on time, build an emergency fund, and save for major expenses such as a car or home. Overall, a budget puts a person on stronger financial footing for both the day-to-day and the long term.
                                    </p>
                            </div>
                                <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Visit Website</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



            <div class="container-xxl py-5">
                <div class="container">
                  <h1 class="mb-3">Valuation</h1>
                    <div class="bg-light rounded p-3">
                        <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                            <div class="row g-5 align-items-center">
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                    <img class="img-fluid rounded w-100" src="img/value.png" alt="">
                                </div>
                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="mb-4">
                                      <h5 class="mb-3">Want to Value your properties or Assets? Approps.ng has an answer!</h5>
                                      <p>Valuation is the analytical process of determining the current (or projected) worth of an asset or a company. In finance, valuation is the process of determining the present value of an asset. In a business context, it is often the hypothetical price that a third party would pay for a given asset. Valuations can be done on assets or on liabilities. What is the purpose of valuation?
The purpose of a valuation is to track the effectiveness of your strategic decision-making process and provide the ability to track performance in terms of estimated change in value, not just in revenue.</p>
                                </div>
                                    <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                    <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Visit Website</a>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- Team Start -->

        <!-- Testimonial End -->
        <div class="container-xxl py-5">
            <div class="container">
              <h1 class="mb-3">Consultancy</h1>
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="img/consultancy.png" alt="">
                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                  <h5 class="mb-3">We provide expert support for your project</h5>
                                  <p>
                                    Consultancy is expert advice on a particular subject which a person or group is paid to provide to a company or organization. For example, a client might ask if it would be better to buy a component or to make it in-house. Alternatively, the consultant could be asked to advise a CEO on whether to abandon a line of business, acquire new business interests, or redefine a marketing strategy. A consulting firm is a business comprised of industry-specific experts who offer professional advice, guidance, and actionable solutions to businesses experiencing issues they can't deal with in-house
                                  </p>
                            </div>
                                <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Visit Website</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
