<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps.ng - Real Estate Management. List your property here</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->


        <!-- Header End -->


        <!-- Search Start -->

        <!-- Search End -->
        <!-- Contact Start -->
                <div class="container-xxl py-5">
                    <div class="container">
                        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                            <h1 class="mb-3">Upload your properties</h1>
                            <p>Fill the form below to list your property and upload the latest pictures of the property. Ensure accurate information and integrity.</p>
                        </div>
                        @if($message = Session:: get('insert_error'))
          <table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center">	{{$message}}</td>
            </tr>
          </table>
        {{  Session::forget('insert_error'); }}
          @endif
          @if($message = Session:: get('insert_success'))
          <table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" style=" font:white;">	{{$message}}</td>
            </tr>
          </table>
        {{  Session::forget('insert_success'); }}
          @endif
          <br>
                        <div class="row g-4">

                          <div class="col-md-6">
                              <div class="wow fadeInUp" data-wow-delay="0.5s">
                                  <form action="listprops" method="post" enctype="multipart/form-data">
                                    	@csrf
                                      <div class="row g-3">
                                        <div class="col-12">
                                            <select class="form-select border-1 py-3" name="ptype">
                                                <option value="-1"selected>Property Type</option>
                                                <option value="Apartment">Apartment</option>
                                                <option value="Villa">Villa</option>
                                                <option value="Home">Home</option>
                                                <option value="Office">Office</option>
                                                <option value="Building">Building</option>
                                                <option value="Shop">Shop</option>
                                                <option value="WareHouse">WareHouse</option>
                                                <option value="Hall">Hall</option>
                                                <option value="Garrage">Garrage</option>
                                            </select>
                                        </div>
                                          <div class="col-12">
                                              <div class="form-floating">
                                                  <input type="text" class="form-control" required="required" min="10" max="250" name="pname" id="subject" placeholder="Subject">
                                                  <label for="subject">Name of the property e.g Approps Villa</label>
                                              </div>
                                          </div>
                                          <div class="col-12">
                                              <div class="form-floating">
                                                  <textarea class="form-control" style="height:70px;"   required="required" name="location" minlength="15"  maxlength="250"  placeholder="Leave a message here" id="message" style="height: 150px"></textarea>
                                                  <label for="message">Location (Enter exact location of the property or address)</label>
                                              </div>
                                          </div>
                                          <div class="col-12">
                                              <select class="form-select border-1 py-3" name="state">
                                                  <option value="Lagos"selected>State/Province</option>

                            <OPTION value=Abia>Abia</OPTION>
                            <OPTION value=Abuja>Abuja</OPTION>
                            <OPTION value=Adamawa>Adamawa</OPTION>
                            <OPTION value='Akwa Ibom'>Akwa Ibom</OPTION>
                            <OPTION value=Anambra>Anambra</OPTION>
                            <OPTION value=Bauchi>Bauchi</OPTION>
                            <OPTION value=Bayelsa>Bayelsa</OPTION>
                            <OPTION value=Benue>Benue</OPTION>
                            <OPTION value='Cross River'>Cross River</OPTION>
                            <OPTION value=Delta>Delta</OPTION>
                            <OPTION value=Ebonyi>Ebonyi</OPTION>
                            <OPTION value=Edo>Edo</OPTION>
                            <OPTION value=Ekiti>Ekiti</OPTION>
                            <OPTION value=Enugu>Enugu</OPTION>
                            <OPTION value=Gombe>Gombe</OPTION>
                            <OPTION value=Imo>Imo</OPTION>
                            <OPTION value=Jigawa>Jigawa</OPTION>
                            <OPTION value=Kaduna>Kaduna</OPTION>
                            <OPTION value=Kano>Kano</OPTION>
                            <OPTION value=Katsina>Katsina</OPTION>
                            <OPTION value=Kebbi>Kebbi</OPTION>
                            <OPTION value=Kogi>Kogi</OPTION>
                            <OPTION value=Kwara>Kwara</OPTION>
                            <OPTION value=Lagos>Lagos</OPTION>
                            <OPTION value=Nassarawa>Nassarawa</OPTION>
                            <OPTION value=Niger>Niger</OPTION>
                            <OPTION value=Ogun>Ogun</OPTION>
                            <OPTION value=Ondo>Ondo</OPTION>
                            <OPTION value=Osun>Osun</OPTION>
                            <OPTION value=Oyo>Oyo</OPTION>
                            <OPTION value=Plateau>Plateau</OPTION>
                            <OPTION value=Rivers>Rivers</OPTION>
                            <OPTION value=Sokoto>Sokoto</OPTION>
                            <OPTION value=Taraba>Taraba</OPTION>
                            <OPTION value=Yobe>Yobe</OPTION>
                            <OPTION value=Zamfara>Zamfara</OPTION>
                                              </select>
                                          </div>

                                          <div class="col-12">
                                              <div class="form-floating">
                                                  <input type="text" class="form-control" max="12" min="5"  required="required" name="cost" id="subject" placeholder="Subject">
                                                  <label for="subject">Cost (What is the value of your property e.5 1,000,000)</label>
                                              </div>
                                          </div>

                                          <div class="col-12">
                                              <select class="form-select border-1 py-3" name="unit">
                                                  <option value="1" selected>Unit (How many units e.g 2 bedrooms)</option>
                                                  <option value="1">1</option>
                                                  <option value="2">2</option>
                                                  <option value="3">3</option>
                                                  <option value="4">4</option>
                                                  <option value="5">5</option>
                                                  <option value="6">6</option>
                                                  <option value="7">7</option>
                                                  <option value="8">8</option>
                                                  <option value="9">9</option>
                                                  <option value="10">10</option>
                                              </select>
                                          </div>

                                          <div class="col-12">
                                              <div class="form-floating">
                                                  <input type="number" max="10000"  required="required" name="sqft" class="form-control" id="subject" placeholder="Subject">
                                                  <label for="subject">Sqft(Square Feet. Size of the property e.g 1000)</label>
                                              </div>
                                          </div>

                                          <div class="col-12">
                                              <select class="form-select border-1 py-3" name="bathroom">
                                                  <option value="1" selected>Bathroom (How many Bathrooms e.g 2)</option>
                                                  <option value="1">1</option>
                                                  <option value="2">2</option>
                                                  <option value="3">3</option>
                                                  <option value="4">4</option>
                                                  <option value="5">5</option>
                                                  <option value="6">6</option>
                                                  <option value="7">7</option>
                                                  <option value="8">8</option>
                                                  <option value="9">9</option>
                                                  <option value="10">10</option>
                                              </select>
                                          </div>

                                          <div class="col-12">
                                              <div class="form-floating">
                                                  <textarea class="form-control" maxlength="500"  required="required" name="details" placeholder="Leave a message here" id="message" style="height: 150px"></textarea>
                                                  <label for="message">Details (Enter full details of the property and comments)</label>
                                              </div>
                                          </div>

                                      </div>

                              </div>
                          </div>
                            <div class="col-md-6">
                                <div class="wow fadeInUp" data-wow-delay="0.5s">
                                      <h4 class="mb-3"  style="background-color:#3366FF; padding:7px;">Agent/Owner's Contact</h4>
                                        <div class="row g-3">

                                            <div class="col-12">
                                                <div class="form-floating">
                                                    <input type="text" class="form-control" max="250" required="required" name="agent" id="subject" placeholder="Subject">
                                                    <label for="subject">Your contact name</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-floating">
                                                    <input type="text" class="form-control" max="100" required="required" name="email" id="subject" placeholder="Subject">
                                                    <label for="subject">E-mail Address</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-floating">
                                                    <input type="text" max="12" min="11" name="mobile" required="required" style="max-lenght:12" class="form-control" id="subject" placeholder="Subject">
                                                    <label for="subject">Mobile number</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-floating">
                                                    <input type="text" max="12" min="11" name="office" required="required" class="form-control" id="subject" placeholder="Subject">
                                                    <label for="subject">Office number</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-floating">
                                                For Sale <input type="radio" required="required" max="12" name="cat" value="For Sale"  style="margin-right:10px;">

                                                 For Rent <input type="radio" required="required" max="12" name="cat" value="For Rent" style="margin-right:10px;">
                                                 Both <input type="radio" required="required" max="12" name="cat" value="Both">

                                                </div>
                                            </div>
                                              <h4 class="mb-3"  style="background-color:#3366FF; padding:7px;">Upload pictures</h4>

                                                <div class="col-12">
                                                    <div class="form-floating">
                                                        <input type="file" required="required"  name="input_img1" class="form-control" id="subject" placeholder="Subject">
                                                        <label for="subject">Front View Image (Max: 1mb)</label>
                                                        <div id="size"></div>
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="form-floating">
                                                      <input type="file"  required="required"  name="input_img2" class="form-control" id="subject" placeholder="Subject">
                                                      <label for="subject">Inner View Image (Max: 1mb)</label>
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="form-floating">
                                                      <input type="file"  required="required" name="input_img3" class="form-control" id="subject" placeholder="Subject">
                                                      <label for="subject">Inner View Image (Max: 1mb)</label>
                                                    </div>
                                                </div>

                                            <div class="col-12">
                                                <button class="btn btn-primary w-100 py-3" type="submit">Upload Property</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact End -->

        <!-- Category Start -->

        <!-- Category End -->


        <!-- About Start -->

        <!-- About End -->


        <!-- Property List Start -->

        <!-- Property List End -->


        <!-- Call to Action Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="img/header.jpg" alt="">
                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                  <h1 class="mb-3">Want to sell your property quickly?</h1>
                                  <p>Advertise with us. Placing an advert on Approps.ng can give you a fast access from users. You can also subscribe to a premium listing and promote your property listing</p>
                            </div>
                                <a href="/contact-us" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="https://wa.me/2348055037772" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Get a quote</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->


        <!-- Team Start -->
        <div class="container-xxl py-5" style="margin-top:-60px;">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Property Agents</h1>
                    <p>Conatct our certified agents. You will never regret doing business with them</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Hargitee Properties</h5>
                                <small>Address:</small>
                                  <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Echelon Properties Limited</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Essential Property</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                              <h5 class="fw-bold mb-0">Affordable Properties</h5>
                              <small>Address:</small>
                                <small>Tel:</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->


        <!-- Testimonial Start -->

        <!-- Testimonial End -->


        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
