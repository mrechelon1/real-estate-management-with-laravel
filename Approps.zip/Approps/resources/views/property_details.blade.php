<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps.ng - Real Estate Management. Property details</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="/lib/animate/animate.min.css" rel="stylesheet">
    <link href="/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="/css/style.css" rel="stylesheet">

  <style>

        * {
          box-sizing: border-box;
        }
        .openBtn {
          display: flex;
          justify-content: left;
        }
        .openButton {
          border: none;
          border-radius: 5px;
          background-color: #1c87c9;
          color: white;
          padding: 14px 20px;
          cursor: pointer;
          position: fixed;
        }
        .loginPopup {
          position: relative;
          text-align: center;
          width: 100%;
          max-width: 100%;
            min-width: 70%;
        }
        .formPopup {
          display: none;
          position: fixed;
          left: 50%;
          top: 25%;
          transform: translate(-50%, 5%);
          border: 1px solid #999999;
          z-index: 9;
        }
        .formContainer {
          max-width: 100%;
            min-width: 100%;
          padding: 10px;
          background-color: #fff;
        }
        .formContainer input[type=text],
        .formContainer input[type=password] {
          width: 100%;
          padding: 15px;
          margin: 5px 0 20px 0;
          border: none;
          background: #eee;
        }
        .formContainer input[type=text]:focus,
        .formContainer input[type=password]:focus {
          background-color: #ddd;
          outline: none;
        }
        .formContainer .btn {
          padding: 12px 20px;
          border: none;
          background-color: #8ebf42;
          color: #fff;
          cursor: pointer;
          width: 100%;
          margin-bottom: 15px;
          opacity: 0.8;
        }
        .formContainer .cancel {
          background-color: #cc0000;
        }
        .formContainer .btn:hover,
        .openButton:hover {
          opacity: 1;
        }
      </style>

</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->


        <!-- Header End -->


        <!-- Search Start -->

        <!-- Search End -->
        <!-- Contact Start -->
                <div class="container-xxl py-5">
                    <div class="container">
                        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" >
                              @foreach($details as $user)
                            <h1 class="mb-3"><b>{{$user->p_name }}</b></h1>
                            <p> <i class="fa fa-map-marker-alt text-primary"></i> {{$user->location}}</p>
                            <h2 class="mb-3">Property Type: {{$user->p_type }} | Cost: N{{number_format($user->cost, 2) }}</h2>
                              @endforeach
                        </div>

                        <div class="row g-4">


                                <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                                    @foreach($details as $user)
                                      <div class="testimonial-item bg-light rounded p-3">
                                        <div class="bg-white border rounded p-4">
                                              <div class="d-flex align-items-center">
                                                <img class="img-fluid flex-shrink-0 rounded" src="{{ url('/props/'.$user->img1) }}" style="width: 450px; height: 350px;">

                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-item bg-light rounded p-3">
                                        <div class="bg-white border rounded p-4">

                                              <div class="d-flex align-items-center">
                                                <img class="img-fluid flex-shrink-0 rounded" src="{{ url('/props/'.$user->img2) }}" style="width: 450px; height: 400px;">

                                            </div>

                                        </div>
                                    </div>
                                    <div class="testimonial-item bg-light rounded p-3">
                                        <div class="bg-white border rounded p-4">
                                          <div class="d-flex align-items-center">
                                            <img class="img-fluid flex-shrink-0 rounded" src="{{ url('/props/'.$user->img3) }}" style="width: 450px; height: 400px;">

                                        </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-item bg-light rounded p-3">
                                        <div class="bg-white border rounded p-4">
                                          <div class="d-flex align-items-center">
                                            <img class="img-fluid flex-shrink-0 rounded" src="{{ url('/props/'.$user->img2) }}" style="width: 450px; height: 400px;">

                                        </div>
                                        </div>
                                    </div>
                                      @endforeach

                          </div>
                            <div class="col-md-6">
                                <div class="wow fadeInUp" data-wow-delay="0.5s">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact End -->

        <!-- Category Start -->

        <!-- Category End -->


        <!-- About Start -->
        {{$pid=""}}
          @foreach($details as $user)
        <?php
         $tel  =$user->tel;
         $email  =$user->email;
         $pid  =$user->id;
        //echo $tel;
        ?>
          <script>
          function change() // no ';' here
          {
              var elem = document.getElementById("myButton1");
               elem.value = "<?php  echo $tel; ?>";
          }
          function change2() // no ';' here
          {
                var elem2 = document.getElementById("myButton2");
                 elem2.value = "<?php  echo $email; ?>";
          }
          </script>
        <div class="container-xxl py-5" style="margin-top:-50px;">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <p class="mb-4"><b>Disclaimer:</b> Check and confirm the ownership of the property before making payment. Approps.ng will not be responsible for any fraud on this site. Report a fraudster to the nearrest police station.</p>
                          <h2 class="mb-4" valign="top">More details:</h2>

                          <p class="mb-4">{{$user->details }}</p>
                          <br>

                            <small><b>Date Listed:</b> {{$user->d_t }}</small>
                            <h4 class="mb-3">Location: {{$user->p_state }}</h4>
                              <p><img src="/img/share.png" width="20px;"> <b>Share this property</b></p>

                                <p class="mb-4" style="margin-top:10px;">
                            <a href="https://twitter.com/intent/tweet
?url=https://approps.ng/props/{{$user->img1}}" target='blank' rel='noopener noreferrer' class="share-btn twitter" style="margin-bottom:5px;">Twitter</a>
                            <a href="https://www.facebook.com/sharer.php?u=https://approps.ng/props/{{$user->img1}}" target='blank' rel='noopener noreferrer' class="share-btn facebook" style="margin-bottom:5px;">Facebook</a>
                            <a href="#" class="share-btn reddit" style="margin-bottom:5px;">Reddit</a>
                            <a href="whatsapp://send?text=https://approps.ng Property Name: {{$user->p_name}}. More details: {{$user->details}} "  data-action='share/whatsapp/share' class="share-btn hackernews" style="margin-bottom:5px;">WhatsApp</a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=https://approps.ng/props/{{$user->img1}}" target='blank' rel='noopener noreferrer' class="share-btn linkedin" style="margin-bottom:5px;">LinkedIn</a>
                            <a href="#" class="share-btn email" style="margin-bottom:5px;">Email</a>
                          </p>
                    </div>

                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h3 class="mb-4">Value: <b>N{{number_format($user->cost, 2) }}</b></h3>
                        <p class="mb-4">Property Category: <b>{{$user->cat }}</b></p>
                        <p><i class="fa fa-check text-primary me-3"></i>No. of Bathroom: {{$user->bath }}</p>
                        <p><i class="fa fa-check text-primary me-3"></i>No. of Units: {{$user->unit }}</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Square Feet: {{$user->sqft }}</p>
                        <input onclick="change()" class="btn btn-primary py-3 px-5 mt-3" type="button" value="Contact Seller" id="myButton1"></input>

                          <input onclick="change2()" class="btn btn-primary py-3 px-5 mt-3" type="button" value="E-mail Seller" id="myButton2"></input>
                          <br><br>
                          <p><i class="fa fa-check text-primary me-3"></i><a href="#"> More ads by this agent</a></p>
                          <p><i class="fa fa-check text-primary me-3"></i><a href="/review=review">Save ad as favorite</a></p>
                          <p><i class="fa fa-check text-primary me-3"></i><a href="/contact-us">Report this ad</a></p>
                    </div>
                </div>
            </div>
        </div>
          @endforeach
        <!-- About End -->


        <!-- Property List Start -->
  @include("review")

    <div class="loginPopup">
      <div class="formPopup" id="popupForm">
        <form action="/submit-review" class="formContainer" method="post">
              @csrf
                <p align="right" onclick="closeForm()"><a href="#">Close</a></p>
          <h3 class="modal-title">Submit Review</h3>

            <h4 class="text-center mt-2 mb-4">
              <i class="fas fa-star star-light submit_star mr-1" id="submit_star_1" data-rating="1"></i>
                <input type="radio" name="rate" value="1">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_2" data-rating="2"></i>
                    <input type="radio" name="rate" value="2">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_3" data-rating="3"></i>
                      <input type="radio" name="rate" value="3">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_4" data-rating="4"></i>
                      <input type="radio" name="rate" value="4">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_5" data-rating="5"></i>
                      <input type="radio" name="rate" value="5">
            </h4>

          <div class="form-group">
            <input type="hidden" name="pid" value="{{$pid}}" id="user_name" class="form-control" placeholder="Enter Your Name" />

            <input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
          </div>

          <div class="form-group">
            <textarea name="user_review" id="user_review" style="width:300px; height:150px;" class="form-control" placeholder="Type Review Here"></textarea>
          </div>
          <br>
          <button type="submit" class="btn">Submit</button>

        </form>
      </div>
    </div>
    <script>
      function openForm() {
        document.getElementById("popupForm").style.display = "block";
      }
      function closeForm() {
        document.getElementById("popupForm").style.display = "none";
      }
    </script>
  
        <!-- Property List End -->

        <div class="container-xxl py-5" style="margin-top:-50px;">
            <div class="container">
              <hr>
              <div class="mb-4">
                  <h3 class="mb-3">Map</h3>
                </div>
        <iframe class="position-relative rounded w-100 h-100"
                                   src="https://www.google.com/maps/embed?q=24 iyala Street, Alausa, Ikeja, Lagos, Nigeria"
                                   frameborder="1" style="min-height: 400px; border:0;" allowfullscreen="" aria-hidden="false"
                                   tabindex="0"></iframe>
                                 </div>
                               </div>
        <!-- Call to Action Start -->

<!-- more adds from this agent -->

        <div class="container-xxl py-5" style="margin-top:-50px;">
                   <div class="container">
                     <hr>
                       <div class="row g-0 gx-5 align-items-end">
                           <div class="col-lg-6">

                               <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                                   <h1 class="mb-3">More Listing from this agent</h1>
                                     </div>
                           </div>

                       </div>
                       <div class="tab-content">
                           <div id="tab-1" class="tab-pane fade show p-0 active">
                               <div class="row g-4">
                                   @foreach($agent as $user)
                                   <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                                       <div class="property-item rounded overflow-hidden">
                                           <div class="position-relative overflow-hidden">
                                               <a href="/details/{{$user->id}}/{{$user->email}}"><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                               <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                               <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                           </div>
                                           <div class="p-4 pb-0">
                                               <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                               <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                               <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                           </div>
                                           <div class="d-flex border-top">
                                               <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                               <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                               <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                           </div>
                                       </div>
                                   </div>
                                     @endforeach

                               </div>
                           </div>


                               </div>
                           </div>
                       </div>

<!-- end of more property -->

        <div class="container-xxl py-5">
            <div class="container">
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                        <div class="row g-5 align-items-center">
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="/img/header2.jpg" alt="Advertize Here">

                            </div>
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                    <h1 class="mb-3">Want to sell your property quickly?</h1>
                                    <p>Advertise with us. Placing an advert on Approps.ng can give you a fast access from users. You can also subscribe to a premium listing and promote your property listing</p>
                                </div>

                                <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Get a quote</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->


        <!-- Team Start -->

        <!-- Testimonial End -->


        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/lib/wow/wow.min.js"></script>
    <script src="/lib/easing/easing.min.js"></script>
    <script src="/lib/waypoints/waypoints.min.js"></script>
    <script src="/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="/js/main.js"></script>
</body>

</html>
