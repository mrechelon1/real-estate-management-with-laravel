<strong>User details: </strong><br>

<strong>Name: </strong>{{ $data->name }} <br>

<strong>Email: </strong>{{ $data->email }} <br>

<strong>Phone: </strong>{{ $data->phone }} <br>

<strong>Subject: </strong>{{ $data->subject }} <br>

<strong>Message: </strong>{{ $data->user_query }} <br><br>
