<div class="charts">
  <div class="mid-content-top charts-grids">
    <div class="middle-content">
        <h4 class="title">New Properties</h4>
      <!-- start content_slider -->
      <div id="owl-demo" class="owl-carousel text-center">

  @foreach($prop as $user)

        <div class="item">
        <a href="/details/{{$user->id}}/{{$user->email}}" title="View Details" target="_blank"><span>{{$user->p_name}}</span>  <img class="lazyOwl img-responsive" data-src="/props/{{$user->img1}}" alt="name" style="width:500px; height:200px;"><span>{{$user->p_state}}</span> </a>
        </div>
  @endforeach
      </div>
    </div>
      <!--//sreen-gallery-cursual---->
  </div>
</div>
