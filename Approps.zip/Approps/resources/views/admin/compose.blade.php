@if(!Session::has('key'))
    @php
        header("Location: " . URL::to('/'), true, 302);
        exit();
    @endphp
@endif
<!DOCTYPE HTML>
<html>
<head>
<title>Property in Nigeria, Property Valuation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="list property, buy land, rent apartment" />
<script type="/application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="/asset/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="/asset/css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="/asset/css/font-awesome.css" rel="stylesheet">
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='/asset/css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->

 <!-- js-->
<script src="/asset/js/jquery-1.11.1.min.js"></script>
<script src="/asset/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts-->

<!-- chart -->
<script src="/asset/js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="/asset/js/metisMenu.min.js"></script>
<script src="/asset/js/custom.js"></script>
<link href="/asset/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="/asset/js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });


        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="/asset/css/owl.carousel.css" rel="stylesheet">
					<script src="/asset/js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->
</head>
<body class="cbp-spmenu-push">
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		@include("admin.menu")
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">

        @if($message = Session:: get('infosuccess'))
        <table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
        <tr>
        <td align="center" style=" font:white;">	{{$message}}</td>
        </tr>
        </table>
        {{  Session::forget('infosuccess'); }}
        @endif
        <h3 class="title1">Compose Mail</h3>

        <div class="col-md-8 compose-right widget-shadow">
          <div class="panel-default">
            <div class="panel-heading">
              Compose New Message
            </div>
            <div class="panel-body">
              <div class="alert alert-info">
                Please fill details to send a new message
              </div>
              <form class="com-mail" action="/send-info" method="post">
                    @csrf
                <input type="text" name="to" class="form-control1 control3" placeholder="To : All Users">
                <input type="text" name="subject" class="form-control1 control3" placeholder="Subject :">
                <textarea rows="6" class="form-control1 control2" placeholder="Message :" name="message" ></textarea>
                <div class="form-group">
                  <div class="btn btn-default btn-file">
                    <i class="fa fa-paperclip"></i> Attachment
                    <input type="file" name="attachment">
                  </div>
                  <p class="help-block">Max. 2MB</p>
                </div>
                <input type="submit" value="Send Message">
              </form>
            </div>
          </div>
        </div>
        <div class="clearfix"> </div>
<br>
	<!-- for amcharts js -->





			</div>
		</div>
	<!--footer-->
	<div class="footer">
	  	@include("admin.footer")
  </div>
    <!--//footer-->
	</div>

	<!-- new added graphs chart js-->


	<!-- //Bootstrap Core JavaScript -->

</body>
</html>
