@if(!Session::has('key'))
    @php
        header("Location: " . URL::to('/'), true, 302);
        exit();
    @endphp
@endif
<!DOCTYPE HTML>
<html>
<head>
<title>Properties in Nigeria. Property Listing</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Buy property in Nigeria" />
<script type="/application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="/asset/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="/asset/css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="/asset/css/font-awesome.css" rel="stylesheet">
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='/asset/css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->

 <!-- js-->
<script src="/asset/js/jquery-1.11.1.min.js"></script>
<script src="/asset/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts-->

<!-- chart -->
<script src="/asset/js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="/asset/js/metisMenu.min.js"></script>
<script src="/asset/js/custom.js"></script>
<link href="/asset/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="/asset/js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });


        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="/asset/css/owl.carousel.css" rel="stylesheet">
					<script src="/asset/js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->
</head>
<body class="cbp-spmenu-push">
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		@include("admin.menu")
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			@include("admin.stat")

		<div class="row-one widgettable">

  				<div class="tables">
      <div class="table-responsive bs-example widget-shadow">
        <h4>Important Information</h4>
        <br>
        <table class="table table-bordered"> <thead > <tr > <th style="width:40px;">#</th> <th>Date Posted</th> <th>Title</th> <th>Message</th> <th>Status</th> <th>Edit</th> <th>Del</th> </tr> </thead>
        <tbody>
          @foreach($allinfo as $user)

          <tr> <th scope="row" align="center">  {{$user->id}}</th> <td>{{$user->date}}</td> <td>{{$user->title}}</td> <td>{{$user->info}}</td> <td>{{$user->status}}</td> <td><input type="button" class = "btn btn-info" value="Edit"/></td><td><a href="/delete-info/{{$user->id}}"><input type="button" class = "btn btn-warning" value="Del" onclick="javascript:return confirm('You are about to delete this item')"/></a></td> </tr>
            @endforeach
              </tbody> </table>
      </div>
    </div>
			<div class="clearfix"> </div>
		</div>
    <br>
				<div class="charts">
					<div class="col-md-4 charts-grids widget">
						<div class="card-header">
							<h4>Bar chart</h4>
						</div>

						<div id="container" style="width: 100%; height:270px;">
							<canvas id="canvas"></canvas>
						</div>
						<button id="randomizeData">Randomize Data</button>
						<button id="addDataset">Add Dataset</button>
						<button id="removeDataset">Remove Dataset</button>
						<button id="addData">Add Data</button>
						<button id="removeData">Remove Data</button>

					</div>

					<div class="col-md-4 charts-grids widget states-mdl" style=" overflow-y: scroll; height:380px;">
						<div class="card-header">
							<h4>Registered Users</h4>
						</div>

            <div class="bs-example widget-shadow" data-example-id="hoverable-table" style="width:800px;">

              <table class="table table-hover" style="width:400px;font-size:15px;"> <thead>
                <tr style="width:500px;;">
                  <th>#</th> <th>Date</th><th>First Name</th> <th>Last Name</th>  <th>E-mail</th> <th>Password</th> <th>Status</th><th>Edit</th><th>Del</th>
                </tr>
               </thead>
                <tbody>
                  @foreach($allusers as $user)
                  <tr>
                    <th scope="row">{{$user->id}}</th> <td>{{$user->date}}</td><td>{{$user->name}}</td> <td>{{$user->lastname}}</td><td>{{$user->email}}</td> <td>{{$user->password}}</td><td>{{$user->status}}</td><td><input type="button" class = "btn btn-info" value="Edit"/></td><td><input type="button" class = "btn btn-warning" value="Del" onclick="javascript:return confirm('You are about to delete this item')"></td>
                  </tr>
                    @endforeach
                </tbody>
               </table>
            </div>

					</div>

					<div class="clearfix"> </div>
				</div>


	<!-- for amcharts js -->


			@include("admin.newprops")

			</div>
		</div>
	<!--footer-->
	<div class="footer">
	  	@include("admin.footer")
  </div>
    <!--//footer-->
	</div>

	<!-- new added graphs chart js-->


	<!-- //Bootstrap Core JavaScript -->

</body>
</html>
