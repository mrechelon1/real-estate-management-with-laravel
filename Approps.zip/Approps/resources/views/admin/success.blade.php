@if(!Session::has('key'))
    @php
        header("Location: " . URL::to('/'), true, 302);
        exit();
    @endphp
@endif
<!DOCTYPE HTML>
<html>
<head>
<title>List property. Property in Nigeria</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="My property. List property. Property valuation, Property development" />
<script type="/application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="/asset/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="/asset/css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="/asset/css/font-awesome.css" rel="stylesheet">
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='/asset/css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->

 <!-- js-->
<script src="/asset/js/jquery-1.11.1.min.js"></script>
<script src="/asset/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts-->

<!-- chart -->
<script src="/asset/js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="/asset/js/metisMenu.min.js"></script>
<script src="/asset/js/custom.js"></script>
<link href="/asset/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="/asset/js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });


        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="/asset/css/owl.carousel.css" rel="stylesheet">
					<script src="/asset/js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->
</head>
<body class="cbp-spmenu-push">
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		@include("admin.menu")
		<!-- //header-ends -->
		<!-- main content start-->

<div id="page-wrapper">
  <div class="main-page">

    <div class="error-page">
      <div class="">
        <h4>RESPONSE</h4>
      </div>
      <br>
      <div class="">
      <h4>  @if($message = Session:: get('properror'))
<table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
<tr>
<td align="center">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('properror'); }}
@endif
@if($message = Session:: get('delprop'))
<table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
<tr>
<td align="center" style=" font:white;">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('delprop'); }}
@endif

  @if($message = Session:: get('conferror'))
<table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
<tr>
<td align="center">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('conferror'); }}
@endif
@if($message = Session:: get('confprop'))
<table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
<tr>
<td align="center" style=" font:white;">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('confprop'); }}
@endif

 @if($message = Session:: get('conterror'))
<table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
<tr>
<td align="center">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('conterror'); }}
@endif
@if($message = Session:: get('delcont'))
<table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
<tr>
<td align="center" style=" font:white;">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('delcont'); }}
@endif

@if($message = Session:: get('reverror'))
<table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
<tr>
<td align="center">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('reverror'); }}
@endif
@if($message = Session:: get('delrev'))
<table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
<tr>
<td align="center" style=" font:white;">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('delrev'); }}
@endif

@if($message = Session:: get('delerror'))
<table width="100%" height="50" style="background-color: #ffcc99;" cellspacing="0" cellpadding="0">
<tr>
<td align="center">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('delerror'); }}
@endif
@if($message = Session:: get('delinfo'))
<table width="100%" height="50" style="background-color:#A9D8B4;" cellspacing="0" cellpadding="0">
<tr>
<td align="center" style=" font:white;">	{{$message}}</td>
</tr>
</table>
{{  Session::forget('delinfo'); }}
@endif

<br></h4>
        <form action="#" method="post" class="search-form">
          <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search" required="">

            <div class="input-group-btn">
            <button type="submit" name="submit" class="btn btn-warning btn-flat"><i class="fa fa-search"></i>
            </button>
            </div>
          </div>
          <!-- /.input-group -->
          </form>
      </div>
      <p>You may return to dashboard or try using the search form. <a href="/admin-portal">Click Here</a></p>
    </div>
  </div>
</div>

	<!-- for amcharts js -->

	<!--footer-->
	<div class="footer">
	  	@include("admin.footer")
  </div>
    <!--//footer-->
	</div>

	<!-- new added graphs chart js-->


	<!-- //Bootstrap Core JavaScript -->

</body>
</html>
