<div class="col_3">
    <div class="col-md-3 widget widget1">
      <div class="r3_counter_box">
              <i class="pull-left fa fa-pie-chart dollar1 icon-rounded"></i>
              <div class="stats">
                <h5><strong>#  @foreach($countprop as $user)
                  {{$user->count}}
                    @endforeach
                </strong></h5>
                <span>Total Properties</span>
              </div>
          </div>
    </div>
    <div class="col-md-3 widget widget1">
      <div class="r3_counter_box">
              <i class="pull-left fa fa-laptop user1 icon-rounded"></i>
              <div class="stats">
                <h5><strong>#
                  @foreach($countusers as $user)
                    {{$user->count}}
                      @endforeach
                </strong></h5>
                <span>Total Users</span>
              </div>
          </div>
    </div>
    <div class="col-md-3 widget widget1">
      <div class="r3_counter_box">
              <i class="pull-left fa fa-money user2 icon-rounded"></i>
              <div class="stats">
                <h5><strong>#
                  @foreach($advert as $user)
                    {{$user->count}}
                      @endforeach
                </strong></h5>
                <span>Advertisers</span>
              </div>
          </div>
    </div>
    <div class="col-md-3 widget widget1">
      <div class="r3_counter_box">
              <i class="pull-left fa fa-pie-chart dollar1 icon-rounded"></i>
              <div class="stats">
                <h5><strong>#
                  @foreach($prem as $user)
                    {{$user->count}}
                      @endforeach
                </strong></h5>
                <span>Premium</span>
              </div>
          </div>
     </div>
    <div class="col-md-3 widget">
      <div class="r3_counter_box">
              <i class="pull-left fa fa-users dollar2 icon-rounded"></i>
              <div class="stats">
                <h5><strong>#
                  @foreach($today as $user)
                    {{$user->count}}
                      @endforeach
                </strong></h5>
                <span>Today Listing</span>
              </div>
          </div>
     </div>
    <div class="clearfix"> </div>
</div>
