<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Approps - Real Estate Management</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
<!-- main header start-->
@include("layouts.header")
        <!-- Navbar End -->


        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
              <div class="col-md-6 p-5 mt-lg-5">
                <br><br><br>
                <h1 class="display-5 animated fadeIn mb-4">Property Listing</h1>
                <p  class="animated fadeIn mb-4 pb-2">Real estate investment just got better, choose from various property categories and enjoy a luxirious apartment.</p>

                      <nav aria-label="breadcrumb animated fadeIn">
                      <ol class="breadcrumb text-uppercase">
                          <li class="breadcrumb-item"><a href="/">Home</a></li>

                          <li class="breadcrumb-item text-body active" aria-current="page">Property List</li>
                      </ol>
                  </nav>
              </div>
                <div class="col-md-6 animated fadeIn">
                    <img class="img-fluid" src="img/header.jpg" alt="">
                </div>
            </div>
        </div>

        <!-- Header End -->


        <!-- Search Start -->
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 25px;">
            <div class="container">
              <form action="search-props" method="get">
                  @csrf
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="text" name="kw" class="form-control border-0 py-3" placeholder="Search Keyword">
                            </div>
                            <div class="col-md-4">
                                <select name="type" class="form-select border-0 py-3">
                                    <option selected>Property Type</option>
                                    <option value="1">For Sale</option>
                                    <option value="2">For Rent</option>
                                    <option value="3">For Lease</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select name="location" class="form-select border-0 py-3">
                                    <option selected>Location</option>
                                    <OPTION value=Abia>Abia</OPTION>
                                    <OPTION value=Abuja>Abuja</OPTION>
                                    <OPTION value=Adamawa>Adamawa</OPTION>
                                    <OPTION value='Akwa Ibom'>Akwa Ibom</OPTION>
                                    <OPTION value=Anambra>Anambra</OPTION>
                                    <OPTION value=Bauchi>Bauchi</OPTION>
                                    <OPTION value=Bayelsa>Bayelsa</OPTION>
                                    <OPTION value=Benue>Benue</OPTION>
                                    <OPTION value='Cross River'>Cross River</OPTION>
                                    <OPTION value=Delta>Delta</OPTION>
                                    <OPTION value=Ebonyi>Ebonyi</OPTION>
                                    <OPTION value=Edo>Edo</OPTION>
                                    <OPTION value=Ekiti>Ekiti</OPTION>
                                    <OPTION value=Enugu>Enugu</OPTION>
                                    <OPTION value=Gombe>Gombe</OPTION>
                                    <OPTION value=Imo>Imo</OPTION>
                                    <OPTION value=Jigawa>Jigawa</OPTION>
                                    <OPTION value=Kaduna>Kaduna</OPTION>
                                    <OPTION value=Kano>Kano</OPTION>
                                    <OPTION value=Katsina>Katsina</OPTION>
                                    <OPTION value=Kebbi>Kebbi</OPTION>
                                    <OPTION value=Kogi>Kogi</OPTION>
                                    <OPTION value=Kwara>Kwara</OPTION>
                                    <OPTION value=Lagos>Lagos</OPTION>
                                    <OPTION value=Nassarawa>Nassarawa</OPTION>
                                    <OPTION value=Niger>Niger</OPTION>
                                    <OPTION value=Ogun>Ogun</OPTION>
                                    <OPTION value=Ondo>Ondo</OPTION>
                                    <OPTION value=Osun>Osun</OPTION>
                                    <OPTION value=Oyo>Oyo</OPTION>
                                    <OPTION value=Plateau>Plateau</OPTION>
                                    <OPTION value=Rivers>Rivers</OPTION>
                                    <OPTION value=Sokoto>Sokoto</OPTION>
                                    <OPTION value=Taraba>Taraba</OPTION>
                                    <OPTION value=Yobe>Yobe</OPTION>
                                    <OPTION value=Zamfara>Zamfara</OPTION>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-dark border-0 w-100 py-3" style="background-color:#3366FF;">Search</button>
                    </div>
                </div>
              </form>
            </div>
        </div>
        <!-- Search End -->


        <!-- Category Start -->

        <!-- Category End -->


        <!-- About Start -->

        <!-- About End -->


        <!-- Property List Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Property Listing</h1>
                            <p>Looking for a property of your dreams, Approps.ng has numerous list of properties that you can check from</p>
                        </div>
                    </div>
                    <div class="col-lg-6 text-start text-lg-end wow slideInRight" data-wow-delay="0.1s">
                        <ul class="nav nav-pills d-inline-flex justify-content-end mb-5">
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-primary active" data-bs-toggle="pill" href="#tab-1">Featured</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-primary" data-bs-toggle="pill" href="#tab-2">For Sell</a>
                            </li>
                            <li class="nav-item me-0">
                                <a class="btn btn-outline-primary" data-bs-toggle="pill" href="#tab-3">For Rent</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <div class="row g-4">

                                  @foreach($users as $user)
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href=""><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                        <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                        <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                        <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                        <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                        <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                    </div>
                                </div>
                            </div>
                                    @endforeach

                            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
                                <a class="btn btn-primary py-3 px-5" href="">Browse More Property</a>
                            </div>
                        </div>
                    </div>

                    <div id="tab-2" class="tab-pane fade show p-0">
                        <div class="row g-4">

                            @foreach($users2 as $user)
                            <div class="col-lg-4 col-md-6">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href=""><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                        <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                        <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                        <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                        <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                        <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                    </div>
                                </div>
                            </div>
                              @endforeach

                            <div class="col-12 text-center">
                                <a class="btn btn-primary py-3 px-5" href="">Browse More Property</a>
                            </div>
                        </div>
                    </div>

                    <div id="tab-3" class="tab-pane fade show p-0">
                        <div class="row g-4">
                          @foreach($user3 as $user)
                          <div class="col-lg-4 col-md-6">
                              <div class="property-item rounded overflow-hidden">
                                  <div class="position-relative overflow-hidden">
                                      <a href=""><img class="img-fluid" src="{{ url('/props/'.$user->img1) }}" alt="" style="width:600px; height:300px;"></a>
                                      <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">{{$user->cat}}</div>
                                      <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{$user->p_type}}</div>
                                  </div>
                                  <div class="p-4 pb-0">
                                      <h5 class="text-primary mb-3">N{{number_format($user->cost, 2)}}</h5>
                                      <a class="d-block h5 mb-2" href="">{{substr($user->p_name, 0, 27)}}</a>
                                      <p><i class="fa fa-map-marker-alt text-primary me-2"></i>{{substr($user->location, 0, 35)}}..</p>
                                  </div>
                                  <div class="d-flex border-top">
                                      <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i>{{$user->sqft}} Sqft</small>
                                      <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i>{{$user->unit}} Bed</small>
                                      <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i>{{$user->bath}} Bath</small>
                                  </div>
                              </div>
                          </div>
                            @endforeach
                            <div class="col-12 text-center">

                                <a class="btn btn-primary py-3 px-5" href="">Browse More Property</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Property List End -->


        <!-- Call to Action Start -->

        <!-- Call to Action End -->


        <!-- Team Start -->

        <!-- Team End -->


        <!-- Testimonial Start -->

        <!-- Testimonial End -->


        <!-- Footer Start -->
        @include("layouts.footer")
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
