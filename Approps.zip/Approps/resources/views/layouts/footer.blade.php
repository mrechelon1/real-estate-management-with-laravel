<style>

      * {
        box-sizing: border-box;
      }
      .openBtn {
        display: flex;
        justify-content: left;
      }
      .openButton {
        border: none;
        border-radius: 5px;
        background-color: #1c87c9;
        color: white;
        padding: 14px 20px;
        cursor: pointer;
        position: fixed;
      }
      .loginPopup {
        position: relative;
        text-align: center;
        width: 100%;
        max-width: 100%;
          min-width: 70%;
      }
      .formPopup {
        display: none;
        position: fixed;
        left: 50%;
        top: 25%;
        transform: translate(-50%, 5%);
        border: 1px solid #999999;
        z-index: 9;
      }
      .formContainer {
        max-width: 100%;
        min-width: 100%;
        padding: 15px;
        background-color: #fff;
      }
      .formContainer input[type=email],
      .formContainer input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 20px 0;
        border: none;
        background: #eee;
      }
      .formContainer input[type=email]:focus,
      .formContainer input[type=password]:focus {
        background-color: white;
        outline: none;
      }
      .formContainer .btn {
        padding: 12px 20px;
        border: none;
        background-color: #8ebf42;
        color: #fff;
        cursor: pointer;
        width: 100%;
        margin-bottom: 15px;
        opacity: 0.8;
      }
      .formContainer .cancel {
        background-color: #cc0000;
      }
      .formContainer .btn:hover,
      .openButton:hover {
        opacity: 1;
      }
    </style>
<div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s" style="background-image:URL('img/footer.png');">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4">Get In Touch</h5>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Alausa, Ikeja, Nigeria.</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+2348055037772</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>contact@approps.ng</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4">Quick Links</h5>
                <a class="btn btn-link text-white-50" href="/">About Us</a>
                <a class="btn btn-link text-white-50" href="contact-us">Contact Us</a>
                <a class="btn btn-link text-white-50" href="more-services">Our Services</a>
                <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                <a class="btn btn-link text-white-50" href="">Terms & Condition</a>
            </div>
            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4">Photo Gallery</h5>
                <div class="row g-2 pt-2">
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-1.jpg" alt="">
                    </div>
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-2.jpg" alt="">
                    </div>
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-3.jpg" alt="">
                    </div>
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-4.jpg" alt="">
                    </div>
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-5.jpg" alt="">
                    </div>
                    <div class="col-4">
                        <img class="img-fluid rounded bg-light p-1" src="/img/property-6.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4">Newsletter</h5>
                <p>Sign in for Newsletter.</p>
                <div class="position-relative mx-auto" style="max-width: 400px;">
                    <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                    <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                </div>
                <br>
                <img src="/img/googleplay.png">
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="border-bottom" href="#">Approps.ng</a>, All Right Reserved.

      <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
      Powered By <a class="border-bottom" href="http://echelontrainingportal.com/">Echelon</a>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="footer-menu">
                        <a href="/">Home</a>
                        <a href="">Cookies</a>
                        <a href="">Help</a>
                        <a href="">FQAs</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="https://wa.me/2348055037772"> <img src="/img/chat.png" style="display: scroll; position: fixed; right: 15px; bottom: 5px; "></a>

</div>
<!-- Footer End -->

  <div class="loginPopup" style=" width:370px; ">
    <div class="formPopup" id="popupForm" style=" width:370px;">
      <form action="/loginform" class="formContainer" method="post">
            @csrf
            <p align="right" onclick="closeForm()"><a href="#">Close</a></p>
        <h2 class="modal-title">User<a href="#"> Login</a></h2>
<br>

        <div class="form-group">
          <input type="email" style=" width:340px;" required="required" autocomplete="off" name="username" id="user_name" class="form-control" placeholder="Enter Your Name" />
        </div>

        <div class="form-group">
          <input type="password" style=" width:340px;" required="required" name="password" id="user_name" class="form-control" placeholder="Enter Your Name" />

        </div>

        <button type="submit" class="btn">Login</button>
        <p> Don't have an account? <a href="new-user">Click here to Register</a></p>
          <p align="left"> <input type="checkbox"> Save password</p>
      </form>
    </div>
  </div>
  <script>
    function openForm() {
      document.getElementById("popupForm").style.display = "block";
    }
    function closeForm() {
      document.getElementById("popupForm").style.display = "none";
    }
  </script>
