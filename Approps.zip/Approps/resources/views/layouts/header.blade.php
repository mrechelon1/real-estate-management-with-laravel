<div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 8px;  align:middle; width:100%;">
    <div class="container" style="margin-bottom:-8px; width:100%;">
        <div class="row g-2">
            <div class="col-md-10"  style="width:100%;">
                <div class="row g-2" style="width:100%;">
                    <div class="col-md-4" style="width:30%;">
<p style="color:white;">Welcome to Approps.ng</p>
                    </div>
                    <div class="col-md-4" style="width:52%;">
                  <p style="color:white;"> <img src="/img/whatsapp.png" width="22" style="margin-right: 5px;">+2348055037772,  +2348062841507</p>
                    </div>
                    <div class="col-md-4" style="width:18%; margin-right:-5px">
                      <p style="color:white;" onclick="openForm()"><a href="#" style="color:white;">Login</a> | <a href="#" style="color:white;">SignUp</a> </p>

                      </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- mainheader end -->

        <!-- Navbar Start -->
        <div class="container-fluid nav-bar bg-transparent" style="margin-top:0px;">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4" >
                <a href="index.html" class="navbar-brand d-flex align-items-center text-center">

                    <a href="/">  <img class="img-fluid" src="/img/mylogo.png" alt="Icon" style="width: 230px; height: 65px;"></a>

                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse" >
                    <div class="navbar-nav ms-auto">
                        <a href="/" class="nav-item nav-link active">Home</a>
                        <a href="about-us" class="nav-item nav-link">About</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Property</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="{{url('/valued-property')}}" class="dropdown-item">Property List</a>
                                <a href="{{url('/valued-property')}}" class="dropdown-item">Property Type</a>
                                <a href="#" class="dropdown-item">Property Agent</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="/more-services" class="dropdown-item">Investment</a>
                                <a href="/more-services" class="dropdown-item">Appropriation</a>
                                <a href="/more-services" class="dropdown-item">Budgeting</a>
                                <a href="/more-services" class="dropdown-item">Valuation</a>
                                <a href="/more-services" class="dropdown-item">Consultancy</a>
                            </div>
                        </div>
                        <a href="{{url('/contact-us')}}" class="nav-item nav-link">Contact</a>
                    </div>
                    <a href="{{url('/list-property')}}" class="btn btn-primary px-3 d-none d-lg-flex">Add Property</a>
                </div>
            </nav>
        </div>
