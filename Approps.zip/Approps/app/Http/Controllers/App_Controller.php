<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Mail;
use Session;
use App\Http\Requests;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\App_Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;


class App_Controller extends Controller
{
    //
    public function insertform(){
       return view('stud_create');
       }
  // upload properties
  public function propsreg(Request $request){
       $ptype = $request->input('ptype');
       $pname = $request->input('pname');
       $location = $request->input('location');
       $state = $request->input('state');
       $cost = $request->input('cost');
       $costf = str_replace(',', '', $cost);
       $unit = $request->input('unit');
       $sqft = $request->input('sqft');
       $bathroom = $request->input('bathroom');
       $details = $request->input('details');
       $agent = $request->input('agent');
       $email = $request->input('email');
       $mobile = $request->input('office');
       $office = $request->input('office');
       $cat = $request->input('cat');
       $tel = $mobile.", ".$office;
       $prem = '0';
       $status='Active';
       $img1 = $request->file('input_img1');

      $filename= date('YmdHi').$img1->getClientOriginalName();

       $img2 = $request->file('input_img2');
       $filename2= date('YmdHi').$img2->getClientOriginalName();
       $img3 = $request->file('input_img3');
       $filename3= date('YmdHi').$img3->getClientOriginalName();

       if($ptype == '-1'){
         session(['insert_error' => 'Error uploading property. Property type cannot be empty']);
       return redirect('list-property');
       }
       else if($img1->getSize() > "500000"){ // in bytes
         session(['insert_error' => 'Error uploading property. Image too large to upload']);
        return redirect('list-property');
       }
       else{

       $data=array('d_t'=>now(),'p_name'=>$pname,"p_type"=>$ptype,"location"=>$location,"p_state"=>$state,"cost"=>$costf,"unit"=>$unit,"sqft"=>$sqft,"bath"=>$bathroom,"details"=>$details,"agent"=>$agent,"tel"=>$tel,"email"=>$email,"cat"=>$cat,"prem"=>$prem,"status"=>$status,"img1"=>$filename,"img2"=>$filename2,"img3"=>$filename3);
       DB::table('properties')->insert($data);

   if($data>0){

    $img1-> move(public_path('props'), $filename);
    $img2-> move(public_path('props'), $filename2);
    $img3-> move(public_path('props'), $filename3);

   session(['insert_success' => 'Your property has been listed successfully: '.$email.' It will be published within 24 hours.']);
   return redirect('list-property');
   }
   else{
   //session()-> now('insert_error' ,'Student record not successful');
     session(['insert_error' => 'Error uploading property with: '.$email]);
   return redirect('list-property');
   //session(['key' => 'value']); it store a session permanent
   //$this->reportable(function (InvalidOrderException $e) {
  // return false;
     //});
   }
   }
 }
 //insert review
 public function my_review(Request $request){
    $rate = $request->input('rate');
      $pid = $request->input('pid');
      $pname = $request->input('user_name');
      $rev = $request->input('user_review');


      $data=array('pid'=>$pid,'user_name'=>$pname,'user_rating'=>$rate,'user_review'=>$rev,'date'=>now());
      DB::table('review_table')->insert($data);

      session(['review_success' => 'Your property review is successful']);
      return redirect('/Apartment');
      }
  // delete property
   public function del_user($userid){
       //  $user_id  = Input::get('userid') ;
         // $user_id = $request->Input('userid');
         $del = DB::delete('delete from student_details where id = "'.$userid.'"');


   if($del>0){
 //	session()-> now('error', 'Student record successfully deleted');
 session(['delerror' => 'Student record successfully deleted with userid: '.$userid]);
   return redirect('view-records');
   //return view('success');
   }
   else{
   session()-> now('delerror' ,'Student record cannnot be deleted');
   return redirect('view-records');
   //session(['key' => 'value']); it store a session permanent
   //$this->reportable(function (InvalidOrderException $e) {
   // return false;
      //});
   }
   }

  // get all properties by  category on index page including number of categories
   public function view_properties(){

      $lagos = DB::select('select p_state,  COUNT(*) AS "count" from properties where p_state="Lagos" GROUP BY p_state LIMIT 1');
      $abuja = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Abuja" GROUP BY p_state LIMIT 1');
      $ogun = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Ogun" GROUP BY p_state LIMIT 1');
      $ph = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Rivers" GROUP BY p_state LIMIT 1');
      $oyo = DB::select('select  p_state, COUNT(*) AS "count" from properties where p_state="Oyo" GROUP BY p_state LIMIT 1');
      $others = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state != "Lagos"  GROUP BY p_state LIMIT 1');
      //by type
      $apart = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Apartment" GROUP BY p_type LIMIT 1');
      $villa = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Villa" GROUP BY p_type LIMIT 1');
      $home = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Home" GROUP BY p_type LIMIT 1');
      $office = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Office" GROUP BY p_type LIMIT 1');
      $build = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Building" GROUP BY p_type LIMIT 1');
      $town = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="WareHouse" GROUP BY p_type LIMIT 1');
      $shop = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="shop" GROUP BY p_type LIMIT 1');
      $garage = DB::select('select p_type, COUNT(*) AS "count" from properties where p_type="Garrage" GROUP BY p_type LIMIT 1');
      //all properties
      $users = DB::select('select * from properties order by id desc limit 9');
      $users2 = DB::select('select * from properties where cat="For Sale" order by id desc limit 9');
      $user3 = DB::select('select * from properties where cat="For Rent" order by id desc limit 9');

       return view('index',['lagos'=>$lagos,'abuja'=>$abuja,'ogun'=>$ogun,'ph'=>$ph,'oyo'=>$oyo,'others'=>$others,'apart'=>$apart,'villa'=>$villa,'home'=>$home,'office'=>$office,'build'=>$build,'town'=>$town,'shop'=>$shop,'garage'=>$garage,'users'=>$users,'users2'=>$users2,'user3'=>$user3]);

       }

public function all_p(){
$users = DB::select('select * from properties order by id desc')->paginate(4);
return view('allproperties', compact('users'));

}

       //about us count
       public function aboutus(){
         $lagos = DB::select('select p_state,  COUNT(*) AS "count" from properties where p_state="Lagos" GROUP BY p_state LIMIT 1');
         $abuja = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Abuja" GROUP BY p_state LIMIT 1');
         $ogun = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Ogun" GROUP BY p_state LIMIT 1');
         $ph = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state="Rivers" GROUP BY p_state LIMIT 1');
         $oyo = DB::select('select  p_state, COUNT(*) AS "count" from properties where p_state="Oyo" GROUP BY p_state LIMIT 1');
         $others = DB::select('select p_state, COUNT(*) AS "count" from properties where p_state != "Lagos"  GROUP BY p_state LIMIT 1');


           return view('about',['lagos'=>$lagos,'abuja'=>$abuja,'ogun'=>$ogun,'ph'=>$ph,'oyo'=>$oyo,'others'=>$others]);

           }

         // get all properties by category
       public function view_allproperties(){

         $users = DB::select('select * from properties order by id desc limit 33');
         $users2 = DB::select('select * from properties where cat="For Sale" order by id desc limit 33');
         $user3 = DB::select('select * from properties where cat="For Rent" order by id desc limit 33');

         return view('allproperties',['users'=>$users,'users2'=>$users2,'user3'=>$user3]);
           }
           // search all properties
           public function propertysearch(Request $request){
             $kw = $request->input('kw');
             $type = $request->input('type');
             $loc = $request->input('location');
             $search = DB::select('select * from properties where (p_name LIKE "%'.$kw.'%" OR location like "%'.$loc.'%" OR location like "%'.$kw.'%") ');

             $users = DB::select('select * from properties order by id desc limit 9');
             $users2 = DB::select('select * from properties where cat="For Sale" order by id desc limit 9');
             $user3 = DB::select('select * from properties where cat="For Rent" order by id desc limit 9');

             return view('searchproperties',['search'=>$search,'users'=>$users,'users2'=>$users2,'user3'=>$user3]);
               }
          // get all properties by type and category
       public function propcat($type){
          $category = DB::select('select * from properties where p_type="'.$type.'"  limit 1');
               $cat = DB::select('select * from properties where p_type="'.$type.'" order by id desc limit 9');
               $cat2 = DB::select('select * from properties where p_type="'.$type.'" AND cat="For Sale" order by id desc limit 9');
               $cat3 = DB::select('select * from properties where p_type="'.$type.'" AND cat="For Rent" order by id desc limit 9');
               return view('property_type',['category'=>$category,'cat'=>$cat,'cat2'=>$cat2,'cat3'=>$cat3]);
          }
          public function propstate($locc){
             $category = DB::select('select * from properties where p_state="'.$locc.'"  limit 1');
                  $cat = DB::select('select * from properties where p_state="'.$locc.'" order by id desc limit 9');
                  $cat2 = DB::select('select * from properties where p_state="'.$locc.'" AND cat="For Sale" order by id desc limit 9');
                  $cat3 = DB::select('select * from properties where p_state="'.$locc.'" AND cat="For Rent" order by id desc limit 9');
                  return view('property_state',['category'=>$category,'cat'=>$cat,'cat2'=>$cat2,'cat3'=>$cat3]);
             }
            // get property details
          public function propdetails($id, $email){
             $details = DB::select('select * from properties where id="'.$id.'"  limit 1');
              $agent = DB::select('select * from properties where email="'.$email.'" order by id desc limit 15');
              $review = DB::select('select COUNT(*) AS "count" from review_table where pid="'.$id.'"  limit 1');
              $fivestar = DB::select('select COUNT(*) AS "count" from review_table where pid="'.$id.'" AND user_rating = "5" limit 1');
              $fourstar = DB::select('select COUNT(*) AS "count" from review_table where pid="'.$id.'" AND user_rating = "4" limit 1');
              $threestar = DB::select('select COUNT(*) AS "count" from review_table where pid="'.$id.'" AND user_rating = "3" limit 1');
             return view('property_details',['details'=>$details,'agent'=>$agent,'review'=>$review,'fivestar'=>$fivestar,'fourstar'=>$fourstar,'threestar'=>$threestar]);
             }
// contact us and email
             public function send_email(Request $request) {
               $type = $request->input('type');
               $gname = $request->input('gname');
               $gemail = $request->input('gemail');
               $title = $request->input('title');
               $me = $request->input('me');

    //Mail::send('AltHr/Portal/welcome', $data, function ($message) use($request) {

        //$message->from($request->mail,$request->name);

        //$message->to('ayussuccess@gmail.com')->subject('Alt Support');

        $data=array('date'=>now(),'cat'=>$type,'name'=>$gname,'email'=>$gemail,'tittle'=>$title,'message'=>$me);
        DB::table('contacts')->insert($data);

    session(['insert_success' => 'Your email has been sent successfully. Thank you for contacting us.']);
    return redirect('contact-us');
                  }

  // send info from Admin
  public function send_info(Request $request) {
    $to = $request->input('to');
    $sub = $request->input('subject');
   $me = $request->input('message');
   $status="1";


//Mail::send('AltHr/Portal/welcome', $data, function ($message) use($request) {

//$message->from($request->mail,$request->name);

//$message->to('ayussuccess@gmail.com')->subject('Alt Support');

$data=array('date'=>now(),'title'=>$sub,'info'=>$me,'status'=>$status);
DB::table('info')->insert($data);
$prop = DB::select('select * from properties order by id desc limit 500');
$today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
$countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
return view('/admin/compose',['today'=>$today,'countcontact'=>$countcontact]);

session(['infosuccess' => 'Message has been sent successfully.']);
return view('/admin/compose',['prop'=>$prop,'today'=>$today,'countcontact'=>$countcontact]);

       }
// admin all contacts
      public function all_contacts(){
      $prop = DB::select('select * from properties order by id desc limit 500');
      $ccontact = DB::select('select * from contacts order by id desc');
      $countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
      $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
      $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
      $countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
      $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
      $allusers = DB::select('select * from users order by id desc');
      $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

      return view('/admin/contacts',['prop'=>$prop,'ccontact'=>$ccontact,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
      }

  // quotations/advertizement
  public function quotations(){
    $prop = DB::select('select * from properties order by id desc limit 500');
  $quote = DB::select('select * from advert order by id desc');
  $countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
  $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
  $countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
  $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
  $allusers = DB::select('select * from users order by id desc');
  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
  return view('/admin/quote',['prop'=>$prop,'quote'=>$quote,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
  }
// compose email
  public function compose(){


  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');

  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
  return view('/admin/compose',['today'=>$today,'countcontact'=>$countcontact]);
  }
//all reviews
public function all_reviews(){
  $prop = DB::select('select * from properties order by id desc limit 500');
$allreviews = DB::select('select * from review_table order by review_id desc');
$countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
$prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
$today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
$countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
$advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
$allusers = DB::select('select * from users order by id desc');
$countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

return view('admin/reviews', ['prop'=>$prop,'allreviews'=>$allreviews,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
             }
// all info
             public function all_info(){
             $prop = DB::select('select * from properties order by id desc limit 500');
             $allinfo = DB::select('select * from info order by id desc');
             $countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
             $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
             $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
             $countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
             $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
             $allusers = DB::select('select * from users order by id desc');
             $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

             return view('admin/info', ['prop'=>$prop,'allinfo'=>$allinfo,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
                          }
   public function loginuser(Request $request){

   $email = $request->input('username');
       $password = $request->input('password');

       if($email === null ){
       session(['loginfailure' => 'You must login to view this page']);
       return redirect('/Apartment');
     }
     else{
      $users = DB::select('select * from users where email = "'.$email.'" AND password = "'.$password.'" limit 1');

 if (count($users) === 0) {

  session(['loginfailure' => 'Username or password is not correct']);
  return redirect('/Apartment');

   }
   else if ( $email === "echelonsoftware@gmail.com"){
   session(['key' => $email]);
   $prop = DB::select('select * from properties order by id desc limit 500');
   $countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
   $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
   $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
   $countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
   $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
   $allusers = DB::select('select * from users order by id desc');
   $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

   return view('admin/index', ['users'=>$users,'prop'=>$prop,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
 }
 else{
   $prop = DB::select('select * from properties where email = "'.$email.'" order by id desc limit 500');
   $prop2 = DB::select('select * from properties order by id desc limit 10');
   $countprop = DB::select('select COUNT(*) AS "count" from properties where email = "'.$email.'" limit 1');
   $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" AND email = "'.$email.'" limit 1');
   $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() AND email = "'.$email.'"limit 1');
   $countusers = DB::select('select COUNT(*) AS "count" from users where email = "'.$email.'" limit 1');
   $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
   $allusers = DB::select('select * from users where email = "'.$email.'" order by id desc');
   $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

    session(['key' => $email]);

   return view('user/index', ['prop'=>$prop,'prop2'=>$prop2,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);

 }
   //session(['key' => 'value']); it store a session permanent
   //$this->reportable(function (InvalidOrderException $e) {
  // return false;
     //});
   }
 }

 public function admin() {
   $prop = DB::select('select * from properties order by id desc limit 500');
   $countprop = DB::select('select COUNT(*) AS "count" from properties limit 1');
   $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" limit 1');
   $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
   $countusers = DB::select('select COUNT(*) AS "count" from users limit 1');
   $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
   $allusers = DB::select('select * from users order by id desc');
   $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

   return view('admin/index', ['prop'=>$prop,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);

 }
   public function logout() {
       Session::flush();
      Session::forget('key');
       return view('index');
   }
// delete property
  public function del_prop($id){

  $del = DB::delete('delete from properties where id = "'.$id.'"');
  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

   if($del>0){
   session(['delprop' => 'Property deleted successfully with I.D:'.$id]);

   return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
   }
   else{
   session()-> now('properror' ,'Property cannnot be deleted');
   return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
   }
   }

//delete contact
   public function del_contact($id){

   $del = DB::delete('delete from contacts where id = "'.$id.'"');
   $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
   $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

    if($del>0){
    session(['delcont' => 'Contact deleted successfully with I.D:'.$id]);

    return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
    }
    else{
    session()-> now('conterror' ,'Contact cannnot be deleted');
    return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
    }
    }
//delete mailbox
    public function del_mail($id){

    $del = DB::delete('delete from info where id = "'.$id.'"');
    $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
    $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

     if($del>0){
     session(['delinfo' => 'Message deleted successfully with I.D:'.$id]);

     return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
     }
     else{
     session()-> now('infoerror' ,'Message cannnot be deleted');
     return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
     }
     }

    //delete contact
       public function del_review($id){

       $del = DB::delete('delete from review_table where review_id = "'.$id.'"');
       $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
       $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

        if($del>0){
        session(['delrev' => 'Review deleted with I.D:'.$id]);

        return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
        }
        else{
        session()-> now('reverror' ,'Review cannnot be deleted');
        return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
        }
        }

   // Confirm property
     public function conf_prop($id){

     $del = DB::delete('update properties set status = "Active" where id = "'.$id.'"');
     $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
     $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

      if($del>0){
      session(['confprop' => 'Property successfully Confirmed with I.D: '.$id]);

      return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
      }
      else{
      session()-> now('conferror' ,'Cannot confirm property. An error occured.');
      return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
      }
      }


   function checklogin(Request $request)
   {
    $this->validate($request, [
     'username'   => 'required|email',
     'password'  => 'required|alphaNum|min:3'
    ]);

    $user_data = array(
     'first_name'  => $request->get('username'),
     'last_name' => $request->get('password')
    );
    $users = DB::table('student_details')->select($user_data);

    if(Auth::attempt($users))
    {
      session(['key' => 'Welcome: '.$email]);
     return view('index');
    }
    else
    {
      session()-> now('error' ,'Wrong Login Details');
 return view('login');
     //return back()->with('error', 'Wrong Login Details');
    }

   }
}
