<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Mail;
use Session;
use App\Http\Requests;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\User_Controller;


class User_Controller extends Controller
{
    //

    public function insertform(){
       return view('stud_create');
       }

       public function register_user(Request $request) {
        $firstname = $request->input('firstname');
        $lastname = $request->input('lastname');
        $email = $request->input('email');
        $gender = $request->input('gender');
        $password = $request->input('password');
        $password2 = $request->input('password2');

        $userexist = DB::select('select * from users where email = "'.$email.'"');
        if($userexist != null){
          session(['reginfo' => 'E-mail already exist. Chat with admin to recover your password. Registration not successful']);
          return redirect('new-user');
        }
        else if($password != $password2){
          session(['reginfo' => 'Password does not match. Registration not successful']);
          return redirect('new-user');
        }else{

       $data=array('date'=>now(),'name'=>$firstname,'lastname'=>$lastname,'email'=>$email,'password'=>$password,'date'=>now(),'level'=>"1",'status'=>"Active");
       DB::table('users')->insert($data);


         $prop = DB::select('select * from properties where email = "'.$email.'" order by id desc limit 500');
         $prop2 = DB::select('select * from properties order by id desc limit 10');
         $countprop = DB::select('select COUNT(*) AS "count" from properties where email = "'.$email.'" limit 1');
         $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" AND email = "'.$email.'" limit 1');
         $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() AND email = "'.$email.'"limit 1');
         $countusers = DB::select('select COUNT(*) AS "count" from users where email = "'.$email.'" limit 1');
         $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
         $allusers = DB::select('select * from users where email = "'.$email.'" order by id desc');
         $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
          session(['key' => $email]);
         return view('user/index', ['prop'=>$prop,'prop2'=>$prop2,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);

}
     }

public function user_log() {
  $email = Session:: get('key');
  //$request->session()->put('key', 'value');

  $prop = DB::select('select * from properties where email = "'.$email.'" order by id desc limit 500');
  $prop2 = DB::select('select * from properties order by id desc limit 10');
  $countprop = DB::select('select COUNT(*) AS "count" from properties where email = "'.$email.'" limit 1');
  $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" AND email = "'.$email.'" limit 1');
  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() AND email = "'.$email.'"limit 1');
  $countusers = DB::select('select COUNT(*) AS "count" from users where email = "'.$email.'" limit 1');
  $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
  $allusers = DB::select('select * from users where email = "'.$email.'" order by id desc');
  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

  return view('user/index', ['prop'=>$prop,'prop2'=>$prop2,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);

}

//User reviews
public function user_reviews($id){
  $email = Session:: get('key');
  $allreviews = DB::select('select * from review_table where pid = "'.$id.'" order by review_id desc');
  $prop = DB::select('select * from properties where email = "'.$email.'" order by id desc limit 500');
  $prop2 = DB::select('select * from properties order by id desc limit 10');
  $countprop = DB::select('select COUNT(*) AS "count" from properties where email = "'.$email.'" limit 1');
  $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" AND email = "'.$email.'" limit 1');
  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() AND email = "'.$email.'"limit 1');
  $countusers = DB::select('select COUNT(*) AS "count" from users where email = "'.$email.'" limit 1');
  $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
  $allusers = DB::select('select * from users where email = "'.$email.'" order by id desc');
  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

  return view('user/reviews', ['allreviews'=>$allreviews,'prop'=>$prop,'prop2'=>$prop2,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
     }

// contact us and email
             public function send_email(Request $request) {
               $gname = $request->input('gname');
               $gemail = $request->input('gemail');
              $title = $request->input('title');
                 $me = $request->input('me');

    //Mail::send('AltHr/Portal/welcome', $data, function ($message) use($request) {

        //$message->from($request->mail,$request->name);

        //$message->to('ayussuccess@gmail.com')->subject('Alt Support');

        $data=array('date'=>now(),'name'=>$gname,'email'=>$gemail,'tittle'=>$title,'message'=>$me);
        DB::table('contacts')->insert($data);


    session(['insert_success' => 'Your email has been sent successfully. Thank you for contacting us.']);
    return redirect('contact-us');
                  }


  // send info from Admin
  public function send_info(Request $request) {
    $to = $request->input('to');
    $sub = $request->input('subject');
   $me = $request->input('message');
   $status="1";


//Mail::send('AltHr/Portal/welcome', $data, function ($message) use($request) {

//$message->from($request->mail,$request->name);

//$message->to('ayussuccess@gmail.com')->subject('Alt Support');

$data=array('date'=>now(),'title'=>$sub,'info'=>$me,'status'=>$status);
DB::table('info')->insert($data);
$prop = DB::select('select * from properties order by id desc limit 500');
$today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
$countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
return view('/admin/compose',['today'=>$today,'countcontact'=>$countcontact]);

session(['infosuccess' => 'Message has been sent successfully.']);
return view('/admin/compose',['prop'=>$prop,'today'=>$today,'countcontact'=>$countcontact]);

       }


  public function compose(){


  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');

  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');
  return view('/admin/compose',['today'=>$today,'countcontact'=>$countcontact]);
  }

// all info
             public function all_info(){

               $email = Session:: get('key');
               $allinfo = DB::select('select * from info order by id desc limit 500');
               $prop = DB::select('select * from properties where email = "'.$email.'" order by id desc limit 500');
               $prop2 = DB::select('select * from properties order by id desc limit 10');
               $countprop = DB::select('select COUNT(*) AS "count" from properties where email = "'.$email.'" limit 1');
               $prem = DB::select('select COUNT(*) AS "count" from properties where prem = "1" AND email = "'.$email.'" limit 1');
               $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() AND email = "'.$email.'"limit 1');
               $countusers = DB::select('select COUNT(*) AS "count" from users where email = "'.$email.'" limit 1');
               $advert = DB::select('select COUNT(*) AS "count" from advert limit 1');
               $allusers = DB::select('select * from users where email = "'.$email.'" order by id desc');
               $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

               return view('user/info', ['allinfo'=>$allinfo,'prop'=>$prop,'prop2'=>$prop2,'countprop'=>$countprop,'countusers'=>$countusers,'advert'=>$advert,'prem'=>$prem,'today'=>$today,'allusers'=>$allusers,'countcontact'=>$countcontact]);
                 

                 }
  //logout
   public function logout() {
       Session::flush();
      Session::forget('key');
       return view('index');
   }
// delete property
  public function del_prop($id){

  $del = DB::delete('delete from properties where id = "'.$id.'"');
  $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
  $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

   if($del>0){
   session(['delprop' => 'Property deleted successfully with I.D:'.$id]);

   return view('user/success', ['countcontact'=>$countcontact,'today'=>$today]);
   }
   else{
   session()-> now('properror' ,'Property cannnot be deleted');
   return view('user/success', ['countcontact'=>$countcontact,'today'=>$today]);
   }
   }

//delete contact
   public function del_contact($id){

   $del = DB::delete('delete from contacts where id = "'.$id.'"');
   $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
   $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

    if($del>0){
    session(['delcont' => 'Contact deleted successfully with I.D:'.$id]);

    return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
    }
    else{
    session()-> now('conterror' ,'Contact cannnot be deleted');
    return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
    }
    }
//delete mailbox
    public function del_mail($id){

    $del = DB::delete('delete from info where id = "'.$id.'"');
    $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
    $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

     if($del>0){
     session(['delinfo' => 'Message deleted successfully with I.D:'.$id]);

     return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
     }
     else{
     session()-> now('infoerror' ,'Message cannnot be deleted');
     return view('admin/success', ['countcontact'=>$countcontact,'today'=>$today]);
     }
     }

    //delete contact
       public function del_review($id){

       $del = DB::delete('delete from review_table where review_id = "'.$id.'"');
       $today = DB::select('select COUNT(*) AS "count" from properties where d_t =  CURRENT_DATE() limit 1');
       $countcontact = DB::select('select  COUNT(*) AS "count" from contacts where date =  CURRENT_DATE() limit 1');

        if($del>0){
        session(['delrev' => 'Review deleted with I.D:'.$id]);

        return view('user/success', ['countcontact'=>$countcontact,'today'=>$today]);
        }
        else{
        session()-> now('reverror' ,'Review cannnot be deleted');
        return view('user/success', ['countcontact'=>$countcontact,'today'=>$today]);
        }
        }

}
